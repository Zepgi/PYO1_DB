﻿namespace PY1_BD.Vista
{
    partial class VistaEstadoReserva
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.botonRegresar = new System.Windows.Forms.Button();
            this.botonAplicarCambioEstadoReserva = new System.Windows.Forms.Button();
            this.comboBoxVerReservas2 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.botonVerReserva = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.textNumReserva = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // botonRegresar
            // 
            this.botonRegresar.BackColor = System.Drawing.Color.Red;
            this.botonRegresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonRegresar.ForeColor = System.Drawing.Color.White;
            this.botonRegresar.Location = new System.Drawing.Point(864, 608);
            this.botonRegresar.Name = "botonRegresar";
            this.botonRegresar.Size = new System.Drawing.Size(108, 41);
            this.botonRegresar.TabIndex = 44;
            this.botonRegresar.Text = "Regresar";
            this.botonRegresar.UseVisualStyleBackColor = false;
            // 
            // botonAplicarCambioEstadoReserva
            // 
            this.botonAplicarCambioEstadoReserva.BackColor = System.Drawing.Color.SaddleBrown;
            this.botonAplicarCambioEstadoReserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonAplicarCambioEstadoReserva.ForeColor = System.Drawing.Color.White;
            this.botonAplicarCambioEstadoReserva.Location = new System.Drawing.Point(425, 324);
            this.botonAplicarCambioEstadoReserva.Name = "botonAplicarCambioEstadoReserva";
            this.botonAplicarCambioEstadoReserva.Size = new System.Drawing.Size(69, 41);
            this.botonAplicarCambioEstadoReserva.TabIndex = 43;
            this.botonAplicarCambioEstadoReserva.Text = "Aplicar";
            this.botonAplicarCambioEstadoReserva.UseVisualStyleBackColor = false;
            this.botonAplicarCambioEstadoReserva.Click += new System.EventHandler(this.botonBorrar_Click);
            // 
            // comboBoxVerReservas2
            // 
            this.comboBoxVerReservas2.FormattingEnabled = true;
            this.comboBoxVerReservas2.Location = new System.Drawing.Point(374, 173);
            this.comboBoxVerReservas2.Name = "comboBoxVerReservas2";
            this.comboBoxVerReservas2.Size = new System.Drawing.Size(171, 21);
            this.comboBoxVerReservas2.TabIndex = 42;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.SaddleBrown;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(297, 240);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(371, 24);
            this.label2.TabIndex = 41;
            this.label2.Text = "Ingrese numero de reserva a modicifar";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(315, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(334, 39);
            this.label1.TabIndex = 40;
            this.label1.Text = "Estados de reserva";
            // 
            // botonVerReserva
            // 
            this.botonVerReserva.BackColor = System.Drawing.Color.SaddleBrown;
            this.botonVerReserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonVerReserva.ForeColor = System.Drawing.Color.White;
            this.botonVerReserva.Location = new System.Drawing.Point(424, 126);
            this.botonVerReserva.Name = "botonVerReserva";
            this.botonVerReserva.Size = new System.Drawing.Size(69, 41);
            this.botonVerReserva.TabIndex = 39;
            this.botonVerReserva.Text = "Ver";
            this.botonVerReserva.UseVisualStyleBackColor = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.SaddleBrown;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(402, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 24);
            this.label7.TabIndex = 38;
            this.label7.Text = "Ver reservas:";
            // 
            // textNumReserva
            // 
            this.textNumReserva.Location = new System.Drawing.Point(393, 284);
            this.textNumReserva.Name = "textNumReserva";
            this.textNumReserva.Size = new System.Drawing.Size(130, 20);
            this.textNumReserva.TabIndex = 45;
            // 
            // VistaEstadoReserva
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Peru;
            this.ClientSize = new System.Drawing.Size(984, 661);
            this.Controls.Add(this.textNumReserva);
            this.Controls.Add(this.botonRegresar);
            this.Controls.Add(this.botonAplicarCambioEstadoReserva);
            this.Controls.Add(this.comboBoxVerReservas2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.botonVerReserva);
            this.Controls.Add(this.label7);
            this.MinimizeBox = false;
            this.Name = "VistaEstadoReserva";
            this.Text = "Hotel Karpas";
            this.Load += new System.EventHandler(this.VistaEstadoReserva_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button botonRegresar;
        public System.Windows.Forms.Button botonAplicarCambioEstadoReserva;
        public System.Windows.Forms.ComboBox comboBoxVerReservas2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Button botonVerReserva;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.TextBox textNumReserva;
    }
}