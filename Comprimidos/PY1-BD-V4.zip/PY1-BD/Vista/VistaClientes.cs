﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PY1_BD.Vista
{
    public partial class VistaClientes : Form
    {
        public VistaClientes()
        {
            InitializeComponent();
        }

        private void textNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void botonActualizar_Click(object sender, EventArgs e)
        {

        }
    }
}
