﻿using PY1_BD.Modelo;
using PY1_BD.Vista;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PY1_BD.Control
{
	public class Controlador {

        public VistaLogin vista;
        public DateTime fechaCheckOut;
        public DateTime fechaCheckIn;
        public DateTime fechaCheckInEstadoReserva;
        public VistaAgregarReservas reservas;
        public VistaBorrarReservas ajustes;
        public VistaEstadoReserva estadoReserva;
        private static readonly SqlConnection bdHotel = new SqlConnection("Data Source = VARGAS2001; Initial Catalog = HOTELKARPAS; Integrated Security = True; Encrypt=False");
        public Controlador(VistaLogin pVista) {
			this.reservas = null;
            this.vista = pVista;

			this.vista.btIngresar.Click += iniciarSesion;
		}

		private void iniciarSesion(object sender, EventArgs e) {
			if (vista.txtCedula.Text == "" || vista.txtContrasena.Text == "") {
				MessageBox.Show("Credenciales Incompletas. Por favor, Llene todos los espacios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			bdHotel.Open();
			SqlCommand login = new SqlCommand("SELECT idCuenta FROM Cuenta WHERE (idUsuario = @idUsuario AND pasword = @password)", bdHotel);
			login.Parameters.AddWithValue("@idUsuario", vista.txtCedula.Text);
			login.Parameters.AddWithValue("@password", vista.txtContrasena.Text);

			try {
				var result = login.ExecuteScalar();
				if (result != null && result != DBNull.Value) {

					vista.Hide();

					SqlCommand rol = new SqlCommand("SELECT idRol FROM Usuario WHERE idUsuario = @idUsuario", bdHotel);
					rol.Parameters.AddWithValue("@idUsuario", vista.txtCedula.Text);
					int numRol = Convert.ToInt32(rol.ExecuteScalar());
					
					if (numRol == 1) {
						VistaAministrador vistaAdmin = new VistaAministrador();
						vistaAdmin.Show();

					} else {
						VistaRecepcionista vistaRecep = new VistaRecepcionista();
						vistaRecep.Show();
					}


				} else {
					MessageBox.Show("Credenciales incorrectas. Por favor, inténtalo de nuevo.");
				}
			} catch (Exception ex) {
				Console.WriteLine("Error: " + ex.Message);
			}
			bdHotel.Close();
		}
		public void agregarReserva(VistaAgregarReservas pVistaAgregarReservas){
			this.reservas = pVistaAgregarReservas;
			this.reservas.Show();
            reservas.botonResgitrarInformacion.Click += AgregarReserva_Aux;
			reservas.botonRegistrarCliente.Click += AgregarCliente;
            reservas.botonChechIn.Click += AgregarCheckIn;
            reservas.botonCheckOut.Click += AgregarCheckOut;
            reservas.botonVerPrecio.Click += VerPrecioTotal;



        }


        private void VerPrecioTotal(object sender, EventArgs e) 
        {
            if (reservas.textIdentificacion.Text == "" || reservas.textCheckIn.Text == "" || reservas.textCheckOut.Text == "" || reservas.comboBoxDescuntos.SelectedItem == null)
            {
                MessageBox.Show("Credenciales Incompletas. Por favor, Llene todos los espacios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
                return;
            }

            try
            {
                Convert.ToInt32(reservas.textIdentificacion.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al validar el idCliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
                return;
                
            }
            finally
            {
                bdHotel.Close();
            }
            //////////////////Validacion idCliente existente/////////////////////////////////////////////////////////////
            bdHotel.Open();
            SqlCommand obtenerIds = new SqlCommand("SELECT idCliente FROM Cliente WHERE (idCliente = @idCliente)", bdHotel);
            obtenerIds.Parameters.AddWithValue("@idCliente",Convert.ToInt32( reservas.textIdentificacion.Text));
            DateTime fechaCheckIn_Aux = fechaCheckIn;

           
            var id = obtenerIds.ExecuteScalar();
            bdHotel.Close();

            if (id == DBNull.Value)
            {
                MessageBox.Show("Cliente no registrado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
                return;
            }

            

            ////////////////////////Validacion precioByhabitacion//////////////////////////
            SqlCommand validarPrecioHabitacion = new SqlCommand("SELECT precio FROM Habitacion WHERE(tipo = @tipo)", bdHotel);
            validarPrecioHabitacion.Parameters.AddWithValue("@tipo", reservas.comboBoxHabitacion.SelectedItem.ToString());
            double precio = 0;
            bdHotel.Open();
            double precioHabitacion = Convert.ToDouble(validarPrecioHabitacion.ExecuteScalar());
            bdHotel.Close();
            /////////////////////////////////////Validacion dias////////////////////////////////////////////////////////////////////////////
            while (fechaCheckIn_Aux != fechaCheckOut.AddDays(1))
            {
                ////Temporadas altas
                if (fechaCheckIn_Aux >= DateTime.Parse("01/06/2024") && fechaCheckIn_Aux <= DateTime.Parse("31/08/2024"))
                {
                    precio += precioHabitacion;

                }
                else if (fechaCheckIn_Aux >= DateTime.Parse("24/03/2024") && fechaCheckIn_Aux <= DateTime.Parse("7/04/2024"))
                {
                    precio += precioHabitacion;
                }
                else if (fechaCheckIn_Aux >= DateTime.Parse("20/12/2024") && fechaCheckIn_Aux <= DateTime.Parse("15/01/2025"))
                {
                    precio += precioHabitacion;
                }
                ////Temporadas medias
                else if (fechaCheckIn_Aux >= DateTime.Parse("01/09/2024") && fechaCheckIn_Aux <= DateTime.Parse("20/10/2024"))
                {
                    precio += precioHabitacion - precioHabitacion * 0.3;
                }
                else if (fechaCheckIn_Aux >= DateTime.Parse("16/01/2024") && fechaCheckIn_Aux <= DateTime.Parse("08/02/2024"))
                {
                    precio += precioHabitacion - precioHabitacion * 0.3;
                }
                else
                {
                    precio += precioHabitacion - precioHabitacion * 0.4;
                }
                 fechaCheckIn_Aux = fechaCheckIn_Aux.AddDays(1);

            }


            /////////////////////////////////////COMBOBOX DE DESCUENTOS////////////////////////////////////////////////////////////////////////////
            bdHotel.Open();
            SqlCommand AgregarDescuentos = new SqlCommand("SELECT COUNT(idCliente) FROM Reserva WHERE descuentoAplicado != 1 and idCliente = @idCliente", bdHotel);
            AgregarDescuentos.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);
            int countadorDescuentos = Convert.ToInt32(AgregarDescuentos.ExecuteScalar());
            bdHotel.Close();

            if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "5% de descuento." && countadorDescuentos >= 5)
            {
                precio -= (precio * 0.05);
            }
            else if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "10% de descuento." && countadorDescuentos >= 6)
            {
                precio -= precio * 0.1;

            }
            else if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "Noche gratis." && countadorDescuentos >= 10)
            {
                fechaCheckOut = fechaCheckOut.AddDays(1);
            }
            else if (reservas.comboBoxDescuntos.SelectedItem.ToString() != "No aplicar descuento.")
            {
                MessageBox.Show("No tienes suficientes puntos para obtener este descuento", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            reservas.labelPrecioTotal.Text = "Precio total: " + precio.ToString();
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void AgregarReserva_Aux(object sender, EventArgs e)
        {
          
            if (reservas.textIdentificacion.Text == "" || reservas.textCheckIn.Text == "" || reservas.textCheckOut.Text == "" || reservas.comboBoxDescuntos.SelectedItem == null)
            {
                MessageBox.Show("Credenciales Incompletas. Por favor, Llene todos los espacios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
                return;
            }
            try
            {
                Convert.ToInt32(reservas.textIdentificacion.Text);
            }
            catch (Exception ex)
            { 
             MessageBox.Show("Error al validar el idCliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
                return;
            }
            finally
            {
                bdHotel.Close();
            }

            //////////////////Validacion idCliente existente/////////////////////////////////////////////////////////////
            bdHotel.Open();
            SqlCommand obtenerIds = new SqlCommand("SELECT idCliente FROM Cliente WHERE (idCliente = @idCliente)", bdHotel);
            obtenerIds.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);

            var id = obtenerIds.ExecuteScalar();
            bdHotel.Close();

            if (id == null && id == DBNull.Value) {
                MessageBox.Show("Cliente no registrado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            DateTime fechaCheckIn_Aux = fechaCheckIn;

           
            ////////////////////////Validacion precioByhabitacion//////////////////////////
            SqlCommand validarPrecioHabitacion = new SqlCommand("SELECT precio FROM Habitacion WHERE(tipo = @tipo)", bdHotel);
            validarPrecioHabitacion.Parameters.AddWithValue("@tipo", reservas.comboBoxHabitacion.SelectedItem.ToString());
            double precio = 0;
            bdHotel.Open();
            double precioHabitacion = Convert.ToDouble(validarPrecioHabitacion.ExecuteScalar());
            bdHotel.Close();

            /////////////////////////////////////Validacion dias////////////////////////////////////////////////////////////////////////////
            while (fechaCheckIn_Aux != fechaCheckOut.AddDays(1))
            {
                ////Temporadas altas
               if(fechaCheckIn_Aux >= DateTime.Parse("01/06/2024") && fechaCheckIn_Aux <= DateTime.Parse("31/08/2024"))
                {
                    precio += precioHabitacion;
                    
                }
                else if (fechaCheckIn_Aux >= DateTime.Parse("24/03/2024") && fechaCheckIn_Aux <= DateTime.Parse("7/04/2024"))
                {
                    precio += precioHabitacion;
                }
                else if (fechaCheckIn_Aux >= DateTime.Parse("20/12/2024") && fechaCheckIn_Aux <= DateTime.Parse("15/01/2025"))
                {
                    precio += precioHabitacion;
                }
               ////Temporadas medias
                else if (fechaCheckIn_Aux >= DateTime.Parse("01/09/2024") && fechaCheckIn_Aux <= DateTime.Parse("20/10/2024"))
                {
                    precio += precioHabitacion - precioHabitacion * 0.3;
                }
                else if (fechaCheckIn_Aux >= DateTime.Parse("16/01/2024") && fechaCheckIn_Aux <= DateTime.Parse("08/02/2024"))
                {
                    precio += precioHabitacion - precioHabitacion*0.3;
                }
                else
                {
                    precio += precioHabitacion - precioHabitacion * 0.4;
                }
                fechaCheckIn_Aux = fechaCheckIn_Aux.AddDays(1);

            }


            /////////////////////////////////////COMBOBOX DE DESCUENTOS////////////////////////////////////////////////////////////////////////////
            
            SqlCommand AgregarDescuentos = new SqlCommand("SELECT COUNT(idCliente) FROM Reserva WHERE descuentoAplicado != 1 and idCliente = @idCliente", bdHotel);
            AgregarDescuentos.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);
            bdHotel.Open(); 
            int countadorDescuentos = Convert.ToInt32(AgregarDescuentos.ExecuteScalar());
            

            if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "5% de descuento." && countadorDescuentos >= 5)
            {
                int contador = 0;
                SqlCommand SelectsIdReservas = new SqlCommand("SELECT idReserva FROM Reserva WHERE idCliente = @idCliente", bdHotel);
                SelectsIdReservas.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);
                SqlDataReader idReservas = SelectsIdReservas.ExecuteReader();
                List<int> ids = new List<int>();
                while (idReservas.Read())
                { 
                    ids.Add(idReservas.GetInt32(0));
                }
                bdHotel.Close();
                foreach(int idactual in ids){
                    if (contador == 5) 
                    {

                        break;                    
                    }
                    bdHotel.Open();
                    SqlCommand updateBit = new SqlCommand("UPDATE Reserva SET descuentoAplicado = 1 WHERE idReserva = @idReserva", bdHotel);
                    updateBit.Parameters.AddWithValue("@idReserva", idactual);
                    updateBit.ExecuteNonQuery();
                    bdHotel.Close();
                    contador++;
                }
                precio -= (precio * 0.05);
            }
            else if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "10% de descuento." && countadorDescuentos >= 6 ) 
            {

                int contador = 0;
                SqlCommand SelectsIdReservas = new SqlCommand("SELECT idReserva FROM Reserva WHERE idCliente = @idCliente", bdHotel);
                SelectsIdReservas.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);
                SqlDataReader idReservas = SelectsIdReservas.ExecuteReader();
                List<int> ids = new List<int>();
                while (idReservas.Read())
                {
                    ids.Add(idReservas.GetInt32(0));
                }
                bdHotel.Close();
                foreach (int idactual in ids)
                {
                    if (contador == 6 )
                    {

                        break;
                    }
                    bdHotel.Open();
                    SqlCommand updateBit = new SqlCommand("UPDATE Reserva SET descuentoAplicado = 1 WHERE idReserva = @idReserva", bdHotel);
                    updateBit.Parameters.AddWithValue("@idReserva", idactual);
                    updateBit.ExecuteNonQuery();
                    bdHotel.Close();
                    contador++;
                }
                precio -= precio * 0.1;

            }else if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "Noche gratis." && countadorDescuentos >= 10)
            {

                int contador = 0;
                SqlCommand SelectsIdReservas = new SqlCommand("SELECT idReserva FROM Reserva WHERE idCliente = @idCliente", bdHotel);
                SelectsIdReservas.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);
                SqlDataReader idReservas = SelectsIdReservas.ExecuteReader();
                List<int> ids = new List<int>();
                while (idReservas.Read())
                {
                    ids.Add(idReservas.GetInt32(0));
                }
                bdHotel.Close();
                foreach (int idactual in ids)
                {
                    if (contador == 10)
                    {

                        break;
                    }
                    bdHotel.Open();
                    SqlCommand updateBit = new SqlCommand("UPDATE Reserva SET descuentoAplicado = 1 WHERE idReserva = @idReserva", bdHotel);
                    updateBit.Parameters.AddWithValue("@idReserva", idactual);
                    updateBit.ExecuteNonQuery();
                    bdHotel.Close();
                    contador++;
                }
                fechaCheckOut = fechaCheckOut.AddDays(1) ;
            }
            else if(reservas.comboBoxDescuntos.SelectedItem.ToString() != "No aplicar descuento.")
            {
                MessageBox.Show("No tienes suficientes puntos para obtener este descuento", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            bdHotel.Close();

            try
            {
                bdHotel.Open();
                SqlCommand encontrarIdHabitacion = new SqlCommand("SELECT idHabitacion FROM Habitacion WHERE(tipo = @tipo)", bdHotel);
                encontrarIdHabitacion.Parameters.AddWithValue("@tipo", reservas.comboBoxHabitacion.SelectedItem.ToString());
                int idHabitacion = Convert.ToInt32(encontrarIdHabitacion.ExecuteScalar());

                int idReserva = 0;

                SqlCommand encontrarMaxIdReserva = new SqlCommand("SELECT MAX(idReserva) FROM Reserva", bdHotel);
                if(encontrarMaxIdReserva.ExecuteScalar() != DBNull.Value)
                {
                    idReserva = Convert.ToInt32(encontrarMaxIdReserva.ExecuteScalar());
                }
               

         

                SqlCommand register = new SqlCommand("INSERT INTO Reserva VALUES (@idReserva, @idCliente,'ACTIVO', @fechaEntrada, @fechaSalida, @idHabitacion, 0, @precioTotal)", bdHotel);
                register.Parameters.AddWithValue("@idReserva", idReserva+1);
                register.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);
                register.Parameters.AddWithValue("@fechaEntrada", fechaCheckIn.ToString("MM-dd-yyyy"));
                register.Parameters.AddWithValue("@fechaSalida", fechaCheckOut.ToString("MM-dd-yyyy"));

                register.Parameters.AddWithValue("@idHabitacion", idHabitacion); 
                register.Parameters.AddWithValue("@precioTotal", precio);
                int rowsAffected = register.ExecuteNonQuery();
                MessageBox.Show("Reserva agregada exitosamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al agregar la reserva: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bdHotel.Close();
            }
        }


        private void AgregarCliente(object sender, EventArgs e) {
            if (reservas.textIdentificacion.Text == "")
            {
                MessageBox.Show("Credenciales Incompletas. Por favor, Llene todos los espacios");
                return;
            }


            bdHotel.Open();
            SqlCommand login = new SqlCommand("SELECT idCliente FROM Cliente WHERE (idCliente = @idCliente)", bdHotel);
            login.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);

  

            
            /////////////////////////////////////COMBOBOX DE HABITACIONES//////////////////////////////////////////////////////////////////////////////

            try
            {


                SqlCommand agregarHabitacion = new SqlCommand("SELECT DISTINCT tipo FROM Habitacion", bdHotel);
                SqlDataReader reader = agregarHabitacion.ExecuteReader();
                //Limpiamos primero el comboBox
                reservas.comboBoxHabitacion.Items.Clear();

                //Agrega los elementos al comboBox
                while (reader.Read())
                {
                    reservas.comboBoxHabitacion.Items.Add(reader["tipo"].ToString());
                }

                //Cierra el lector y la coneccion
                reader.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: No se cargaron los tipos de habitaciones: " + ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
            }

            if (reservas.comboBoxHabitacion.SelectedIndex == -1)
            {
                MessageBox.Show("por favor, selecciones una habitacion disponible", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
                return;
            }
            bdHotel.Close();



        }
        private void AgregarCheckIn(object sender, EventArgs e) {
            fechaCheckIn = reservas.monthCalendario.SelectionRange.Start;
            reservas.textCheckIn.Text = fechaCheckIn.ToShortDateString();
          
        }

        private void AgregarCheckOut(object sender, EventArgs e)
        {
            fechaCheckOut = reservas.monthCalendario.SelectionRange.Start;
            reservas.textCheckOut.Text = fechaCheckOut.ToShortDateString();

        }




        public void borrarReservas(VistaBorrarReservas pVistaBorrarReservas)
        {
            this.ajustes = pVistaBorrarReservas;
            this.ajustes.Show();
            ajustes.botonVerReservas.Click += verReservas;
            //ajustes.botonRegresar.Click += regresar
            ajustes.botonBorrarReservas.Click += borrarReservas_Aux;

        }

       
        private void verReservas(object sender, EventArgs e)
        {
            
            try
            {
                bdHotel.Open();
                /////ComboBox VerReservas:
                MessageBox.Show("Ya puedes ver la informacion de reservas: ", "Confirmacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
                SqlCommand verReservas = new SqlCommand("SELECT DISTINCT idReserva, idCliente, estadoReserva FROM Reserva ", bdHotel);
                SqlDataReader reader = verReservas.ExecuteReader();
                //Limpiamos primero el comboBox
                ajustes.comboBoxVerReservas.Items.Clear();

                //Agrega los elementos al comboBox
                while (reader.Read())
                {
                    string item = reader["idReserva"].ToString() + " | " +
                                  reader["idCliente"].ToString() + " | " +
                                  reader["estadoReserva"].ToString();
                    ajustes.comboBoxVerReservas.Items.Add(item);
                }

                //Cierra el lector y la coneccion
                reader.Close();
                bdHotel.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: No se cargaron los tipos de reserva: " + ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
               
            }
            finally
            {
                bdHotel.Close();
            }
        }

        private void borrarReservas_Aux(object sender, EventArgs e)
        {
            if (ajustes.comboBoxVerReservas.Text == "")
            {
                MessageBox.Show("Seleccione una reserva a eliminar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (ajustes.comboBoxVerReservas.SelectedItem == null)
            {
                MessageBox.Show("Seleccione una reserva a eliminar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                // Abre la conexión a la base de datos
                bdHotel.Open();

                // Obtiene el valor seleccionado del ComboBox
                string selectedItem = ajustes.comboBoxVerReservas.SelectedItem.ToString();

                // Divide el valor seleccionado en sus partes (idReserva, idCliente, estadoReserva)
                string[] parts = selectedItem.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                string idReserva = parts[0].Trim();
                string idCliente = parts[1].Trim();
                string estadoReserva = parts[2].Trim();
                if(estadoReserva == "ACTIVO")
                {
                    MessageBox.Show("Reserva no eliminada, estado a 'ACTIVO'","ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Verifica si la reserva aún existe en la base de datos
                SqlCommand verificarReserva = new SqlCommand("SELECT Count(idReserva, idCliente, estadoReserva) FROM Reserva WHERE idReserva = @idReserva AND idCliente = @idCliente AND estadoReserva = @estadoReserva", bdHotel);
                verificarReserva.Parameters.AddWithValue("@idReserva", idReserva);
                verificarReserva.Parameters.AddWithValue("@idCliente", idCliente);
                verificarReserva.Parameters.AddWithValue("@estadoReserva", estadoReserva);
                int rowCount = (int)verificarReserva.ExecuteScalar();

                if (rowCount == 0)
                {
                    MessageBox.Show("La reserva seleccionada ya ha sido eliminada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ajustes.comboBoxVerReservas.Text = "";
                    ajustes.comboBoxVerReservas.Items.Clear();

                    return;
                }

                // Construye la consulta SQL para eliminar la reserva
                string query = "DELETE FROM Reserva WHERE idReserva = @idReserva AND idCliente = @idCliente AND estadoReserva = @estadoReserva";

                // Crea y configura el comando SQL
                SqlCommand eliminarReserva = new SqlCommand(query, bdHotel);
                eliminarReserva.Parameters.AddWithValue("@idReserva", idReserva);
                eliminarReserva.Parameters.AddWithValue("@idCliente", idCliente);
                eliminarReserva.Parameters.AddWithValue("@estadoReserva", estadoReserva);

                // Ejecuta la consulta SQL
                int rowsAffected = eliminarReserva.ExecuteNonQuery();

                // Verifica si se eliminó correctamente la reserva
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Reserva eliminada correctamente", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ajustes.comboBoxVerReservas.Items.Clear();
                    ajustes.comboBoxVerReservas.Text = "";
                }
                else
                {
                    MessageBox.Show("No se pudo eliminar la reserva", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ajustes.comboBoxVerReservas.Items.Clear();
                    ajustes.comboBoxVerReservas.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar eliminar la reserva: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Cierra la conexión a la base de datos
                bdHotel.Close();
            }
        }

        public void ajusteReserva(VistaEstadoReserva pVistaEstadoReserva)
        {
            this.estadoReserva = pVistaEstadoReserva;
            this.estadoReserva.Show();

            estadoReserva.botonAplicarCambioEstadoReserva.Click += ajusteReserva_Aux;
            estadoReserva.botonVerReserva.Click += verReservasEstado;
            //estadoReserva.botonRegresar.Click += regresarReservaEstado;



        }
        public void ajusteReserva_Aux(object sender, EventArgs e)
        {
            if ( estadoReserva.textNumReserva.Text == "" )
            {

                MessageBox.Show("Credenciales Incompletas. Por favor, Llene todos los espacios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
                return;
            }
            if (!estadoReserva.textNumReserva.Text.All(char.IsDigit))
            {
                MessageBox.Show("El número de reserva solo puede contener caracteres numéricos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
                return;
            }
            try
            {
                Convert.ToInt32(estadoReserva.textNumReserva.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al validar el idReserva: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
                return;
            }
            finally
            {
                bdHotel.Close();
            }
            //////////////////Validacion idReserva existente/////////////////////////////////////////////////////////////
            bdHotel.Open();
            SqlCommand obtenerIdReserva = new SqlCommand("SELECT idReserva FROM Reserva WHERE (idReserva = @idReserva)", bdHotel);
            obtenerIdReserva.Parameters.AddWithValue("@idReserva", Convert.ToInt32(estadoReserva.textNumReserva.Text));
            ///fechaCheckIn_Aux2
            DateTime fechaCheckIn_Aux2 = DateTime.Now;


            var idReserva = obtenerIdReserva.ExecuteScalar();
            bdHotel.Close();

            if (idReserva == DBNull.Value)
            {
                MessageBox.Show("Reserva no registrada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
                return;
            }


            /////////////////////////////////////Validacion dias////////////////////////////////////////////////////////////////////////////
            /////////////////////////////////////Validacion dias///////////////////////////////////////////////////////////////////////////
            
                // Verificar si fechaCheckIn_Aux2 no pasa de 2 días
                if ((fechaCheckIn_Aux2 - fechaCheckIn).TotalDays <= 2)
                {
                    MessageBox.Show("Error: CANCELACION NO APLICABLE, ESTAS CANCELANDO FALTANDO 1 DIA O 2 PARA TU RESERVA.","ERR0R", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                bdHotel.Open();
                SqlCommand cambiarEstadoReserva = new SqlCommand("UPDATE Reserva SET estadoReserva = 'Cancelado/Pendiente a borrar' WHERE idReserva = @idReserva", bdHotel);
                cambiarEstadoReserva.Parameters.AddWithValue("@idReserva", Convert.ToInt32(estadoReserva.textNumReserva.Text)); // Cambiar a idReserva
                cambiarEstadoReserva.ExecuteNonQuery(); // Ejecuta el comando para actualizar el estado


                try
                {
                    int rowsAffected = cambiarEstadoReserva.ExecuteNonQuery(); // Ejecutar el comando para actualizar el estado
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("CONFIRMACION: Se cambió el estado exitosamente.", "NOTICIA", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("No se encontró ninguna reserva con el ID proporcionado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("ERROR: No se cambió el estado de la reserva: " + ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    bdHotel.Close();
                }

            

        }



        private void verReservasEstado(object sender, EventArgs e)
        {

            try
            {
                bdHotel.Open();
                /////ComboBox VerReservas:
                MessageBox.Show("Ya puedes ver la informacion de reservas: ", "Confirmacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
                SqlCommand verReservasEstado = new SqlCommand("SELECT DISTINCT idReserva, idCliente, estadoReserva,fechaEntrada FROM Reserva ", bdHotel);
                SqlDataReader reader = verReservasEstado.ExecuteReader();
                //Limpiamos primero el comboBox
                estadoReserva.comboBoxVerReservas2.Items.Clear();

                //Agrega los elementos al comboBox
                while (reader.Read())
                {
                    string item = reader["idReserva"].ToString() + " | " +
                                  reader["idCliente"].ToString() + " | " +
                                  reader["fechaEntrada"].ToString() + " | " +
                                  reader["estadoReserva"].ToString();
                    estadoReserva.comboBoxVerReservas2.Items.Add(item);
                }

                //Cierra el lector y la coneccion
                reader.Close();
                bdHotel.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: No se cargaron los tipos de reserva: " + ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            finally
            {
                bdHotel.Close();
            }
        }
       
        

        

    }


}
