﻿namespace PY1_BD
{
}

namespace PY1_BD {


	public partial class HOTELKARPASDataSet1 {
	}
}
