﻿using PY1_BD.Vista;
using PY1_BD.Modelo;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security;
using System.Drawing.Text;

namespace PY1_BD.Control
{
	public class Controlador {

		public DateTime fechaCheckOut;
		public DateTime fechaCheckIn;
		public DateTime fechaCheckInEstadoReserva;

		/////// VISTAS ////////

		public VistaLogin             vistaLogin;
		public VistaOpciones          vistaOpciones;
		public VistaAgregarPersonal   vwAddClient;
		public VistaModificarClientes vwModClient;
		public VistaEliminarClientes  vwDelClient;


		public VistaAgregarReservas reservas;
		public VistaBorrarReservas ajustes;
		public VistaEstadoReserva estadoReserva;



		  //************************************************************************//
		 ////////////////////////////////////////////////////////////////////////////
		////////                      CÓDIGO EYDEN SU                       ////////

		private static readonly SqlConnection bdHotel = new SqlConnection("Data Source=EYDEN;Initial Catalog=HOTELKARPAS;Integrated Security=True");
		public Controlador(VistaLogin pVista) {

			this.vistaLogin = pVista;
			this.vistaOpciones = null;
			this.vwModClient = null;
			this.vwDelClient = null;
			this.vwAddClient = null;
			this.vistaLogin.btIngresar.Click += iniciarSesion;
		}

		private void iniciarSesion(object sender, EventArgs e) {
			if (vistaLogin.txtCedula.Text == "" || vistaLogin.txtContrasena.Text == "") {
				MessageBox.Show("Credenciales Incompletas. Por favor, Llene todos los espacios");
				return;
			}
			SqlCommand login = new SqlCommand("SELECT idCuenta FROM Cuenta WHERE (idUsuario = @idUsuario AND pasword = @password)", bdHotel);
			login.Parameters.AddWithValue("@idUsuario", vistaLogin.txtCedula.Text);
			login.Parameters.AddWithValue("@password", vistaLogin.txtContrasena.Text);

			try {
				bdHotel.Open();
				var result = login.ExecuteScalar();
				bdHotel.Close();

				if (result != null && result != DBNull.Value) {

					vistaLogin.Hide();
					bdHotel.Open();
					SqlCommand rol = new SqlCommand("SELECT idRol FROM Usuario WHERE idUsuario = @idUsuario", bdHotel);
					rol.Parameters.AddWithValue("@idUsuario", vistaLogin.txtCedula.Text);
					int numRol = Convert.ToInt32(rol.ExecuteScalar());
					bdHotel.Close();

					if (numRol == 1) {
						this.vistaOpciones = new VistaOpciones(true);
						this.vistaOpciones.Show();

					} else {
						this.vistaOpciones = new VistaOpciones(false);
						this.vistaOpciones.btPersonal.Enabled = false;
						this.vistaOpciones.Show();
					}
					menuOpciones(vistaLogin.txtCedula.Text);

				} else {
					MessageBox.Show("Credenciales incorrectas. Por favor, inténtalo de nuevo.");
				}
			} catch (Exception ex) {
				Console.WriteLine("Error: " + ex.Message);
			}
		}

		private void cerrarVentana(object sender, EventArgs e) {
			vistaLogin.Close();
		}

		public void cerrarSesion(object sender, EventArgs e) {
			this.vistaLogin.Show();
			this.vistaLogin.txtCedula.Text = "";
			this.vistaLogin.txtContrasena.Text =  "";
			this.vistaOpciones.Dispose();
		}

		public void menuOpciones(string pIdUsuario) {
			string idUsuario = pIdUsuario;

			this.vistaOpciones.FormClosed += cerrarVentana;

			bdHotel.Open();
			SqlCommand findUser = new SqlCommand("SELECT nombreCompleto FROM Usuario WHERE idUsuario = @idUsuario", bdHotel);
			findUser.Parameters.AddWithValue("@idUsuario", idUsuario);
			var name = findUser.ExecuteScalar();
			bdHotel.Close();

			this.vistaOpciones.lbWelcome.Text = "Bienvenido, " + name + ".";
			this.vistaOpciones.btClientes.Click += btClientes_Click;
			this.vistaOpciones.btReservas.Click += btReservas_Click;
			this.vistaOpciones.btReportes.Click += btReportes_Click;
			this.vistaOpciones.btPersonal.Click += btPersonal_Click;
			this.vistaOpciones.btLogout.Click += cerrarSesion;

			this.vistaOpciones.btAdd.Click += btAddSolveCall;
			this.vistaOpciones.btMod.Click += btModSolveCall;
			this.vistaOpciones.btDel.Click += btDelsolveCall;
		}

		 //#################################################################################//
		//################################################################################//

		private void btClientes_Click(object sender, EventArgs e) {
			this.vistaOpciones.setActive("Clientes");
			this.vistaOpciones.btAdd.Visible = true;
			this.vistaOpciones.btAdd.Text = "Añadir Clientes";
			this.vistaOpciones.btMod.Visible = true;
			this.vistaOpciones.btMod.Text = "Modificar Clientes";
			this.vistaOpciones.btDel.Visible = true;
			this.vistaOpciones.btDel.Text = "Eliminar Clientes";
			if (!this.vistaOpciones.esAdmin) {
				this.vistaOpciones.btDel.Enabled = false;
			}
		}

		private void btReservas_Click(object pSender, EventArgs pE) {
			this.vistaOpciones.setActive("Reservas");
			this.vistaOpciones.btAdd.Visible = true;
			this.vistaOpciones.btAdd.Text = "Añadir Reserva";
			this.vistaOpciones.btMod.Visible = true;
			this.vistaOpciones.btMod.Text = "Modificar Reserva";
			this.vistaOpciones.btDel.Visible = true;
			this.vistaOpciones.btDel.Text = "Eliminar Reserva";
			if (!this.vistaOpciones.esAdmin) {
				this.vistaOpciones.btDel.Enabled = false;
			}

		}

		private void btReportes_Click(object pSender, EventArgs pE) {
			this.vistaOpciones.setActive("Reportes");
			this.vistaOpciones.btAdd.Visible = false;
			this.vistaOpciones.btMod.Visible = false;
			this.vistaOpciones.btDel.Visible = false;
		}
		
		private void btPersonal_Click(object sender, EventArgs e) {
			this.vistaOpciones.setActive("Personal");
			this.vistaOpciones.btAdd.Visible = true;
			this.vistaOpciones.btAdd.Text = "Añadir Personal";
			this.vistaOpciones.btMod.Visible = true;
			this.vistaOpciones.btMod.Text = "Modificar Personal";
			this.vistaOpciones.btDel.Visible = true;
			this.vistaOpciones.btDel.Text = "Eliminar Personal";
		}


		 //#################################################################################//
		//################################################################################//




		private void btAddSolveCall(object pSender, EventArgs pE) {

			if (this.vistaOpciones.getActive() == "Clientes") {
				this.vwAddClient = new VistaAgregarClientes(this.vistaOpciones);
				this.vwAddClient.FormClosed += cerrarVentana;
				this.vwAddClient.Show();
				this.vwAddClient.btAgregar.Click += btAgregarCliente_Click;
			} else if (this.vistaOpciones.getActive() == "Reservas") {
				agregarReserva(new VistaAgregarReservas(this.vistaOpciones));
			} else if (this.vistaOpciones.getActive() == "Reportes") {

			} else if (this.vistaOpciones.getActive() == "Personal") {

			}
			return;
		}

		private void btModSolveCall(object pSender, EventArgs pE) {
			if (this.vistaOpciones.getActive() == "Clientes") {
				this.vwModClient = new VistaModificarClientes(this.vistaOpciones, this.vistaOpciones.esAdmin);
				this.vwModClient.FormClosed += cerrarVentana;
				Clientes clientManager = new Clientes(bdHotel);
				List<string> clientList = clientManager.getClientes();
				if (clientList == null || clientList.Count == 0) {
					MessageBox.Show("No hay clientes para modificar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
					return;
				}
				this.vwModClient.cbListaClientes.Items.AddRange(clientList.ToArray());
				this.vwModClient.cbListaClientes.SelectedIndexChanged += cbListaClientes_Mod_Listener;
				this.vwModClient.txtBuscar.KeyPress += txtBuscar_Listener;
				this.vwModClient.readOnly();
				this.vwModClient.Show();
				this.vwModClient.btModificarCliente.Click += btModificarCliente_Click;
				this.vwModClient.btBuscarCliente.Click += btBuscarCliente_Mod_Click;
			} else if (this.vistaOpciones.getActive() == "Reservas") {
				ajusteReserva(new VistaEstadoReserva(this.vistaOpciones));
			} else if (this.vistaOpciones.getActive() == "Reportes") {

			} else if (this.vistaOpciones.getActive() == "Personal") {

			}
			return;
		}

		private void btDelsolveCall(object pSender, EventArgs pE) {
			if (this.vistaOpciones.getActive() == "Clientes") {
				this.vwDelClient = new VistaEliminarClientes(this.vistaOpciones);
				this.vwDelClient.FormClosed += cerrarVentana;
				Clientes clientManager = new Clientes(bdHotel);
				List<string> clientList = clientManager.getClientes();
				if (clientList == null || clientList.Count == 0) {
					MessageBox.Show("No hay clientes para eliminar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
					return;
				}
				this.vwDelClient.cbListaClientes.Items.AddRange(clientList.ToArray());
				this.vwDelClient.cbListaClientes.SelectedIndexChanged += cbListaClientes_Del_Listener;
				this.vwDelClient.txtBuscar.KeyPress += txtBuscar_Listener;
				this.vwDelClient.readOnly();
				this.vwDelClient.Show();
				this.vwDelClient.btEliminarCliente.Click += btEliminarCliente_Click;
				this.vwDelClient.btBuscarCliente.Click += btBuscarCliente_Del_Click;
			} else if (this.vistaOpciones.getActive() == "Reservas") {
				borrarReservas(new VistaBorrarReservas(this.vistaOpciones));
			} else if (this.vistaOpciones.getActive() == "Reportes") {

			} else if (this.vistaOpciones.getActive() == "Personal") {

			}
			return;
		}



		//#################################################################################//
		//################################################################################//


		private void btAgregarCliente_Click(object sender, EventArgs e) {
			Clientes clientManager = new Clientes(bdHotel);

			if (this.vwAddClient.txtCedula.Text == "Ej: 123456789"     ||
				this.vwAddClient.txtNombre.Text == "Ej: Eyden Su Díaz" ||
				this.vwAddClient.txtPais.Text == "Ej: Costa Rica"      ||
				this.vwAddClient.txtTelefono.Text == "Ej: 88888888"    ||
				this.vwAddClient.txtEmail.Text == "Ej: ejemplo@gmail.com") {
				MessageBox.Show("Error: No deje espacios en blanco", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			if (clientManager.buscarCliente(this.vwAddClient.txtCedula.Text) != null) {
				MessageBox.Show("Cliente: Cédula ya registrada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			if (!verifyFormat(this.vwAddClient.txtCedula.Text, "space")  || 
				!verifyFormat(this.vwAddClient.txtCedula.Text, "")       ||
				this.vwAddClient.txtCedula.Text.Length < 9) {
				MessageBox.Show("Cédula: Formato incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			if (!verifyFormat(this.vwAddClient.txtNombre.Text, "space") ||
				!verifyFormat(this.vwAddClient.txtNombre.Text, "text")) {
				MessageBox.Show("Nombre: Formato incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			if (!verifyFormat(this.vwAddClient.txtPais.Text, "space") ||
				!verifyFormat(this.vwAddClient.txtPais.Text, "text")) {
				MessageBox.Show("Pais Natal: Formato incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			if (!verifyFormat(this.vwAddClient.txtTelefono.Text, "space") ||
				!verifyFormat(this.vwAddClient.txtTelefono.Text, "")      ||
				this.vwAddClient.txtTelefono.Text.Length < 8) {
				MessageBox.Show("Télefono: Formato incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			if (!verifyFormat(this.vwAddClient.txtEmail.Text, "space")) {
				MessageBox.Show("Correo Electrónico: Formato incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			int    idCliente = Convert.ToInt32(this.vwAddClient.txtCedula.Text);
			string nombre    = this.vwAddClient.txtNombre.Text;
			string pais      = this.vwAddClient.txtPais.Text;
			int    telefono  = Convert.ToInt32(this.vwAddClient.txtTelefono.Text);
			string email     = this.vwAddClient.txtEmail.Text;
			
			clientManager.agregarCliente(idCliente, nombre, pais, telefono, email);

			MessageBox.Show("Cliente agregado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

			this.vwAddClient.defaultText();
		}

		public void btBuscarCliente_Mod_Click(object sender, EventArgs e) {
			if (this.vwModClient.txtBuscar.Text == null || this.vwModClient.txtBuscar.Text == "") {
				MessageBox.Show("Buscar Cédula: Debe ingresar una cédula", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			if (!verifyFormat(this.vwModClient.txtBuscar.Text, "space") ||
				!verifyFormat(this.vwModClient.txtBuscar.Text, "") ||
				this.vwModClient.txtBuscar.Text.Length < 9) {
				MessageBox.Show("Buscar Cédula: Formato incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			Clientes clientManager = new Clientes(bdHotel);
			string idCliente = this.vwModClient.txtBuscar.Text;
			string[] cliente = clientManager.buscarCliente(idCliente);

			this.vwModClient.setText(cliente);
			this.vwModClient.enWrite();
		}

		public void btBuscarCliente_Del_Click(object sender, EventArgs e) {
			if (this.vwDelClient.txtBuscar.Text == null || this.vwDelClient.txtBuscar.Text == "") {
				MessageBox.Show("Buscar Cédula: Debe ingresar una cédula", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			if (!verifyFormat(this.vwDelClient.txtBuscar.Text, "space") ||
				!verifyFormat(this.vwDelClient.txtBuscar.Text, "") ||
				this.vwDelClient.txtBuscar.Text.Length < 9) {
				MessageBox.Show("Buscar Cédula: Formato incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			Clientes clientManager = new Clientes(bdHotel);
			string idCliente = this.vwDelClient.txtBuscar.Text;
			string[] cliente = clientManager.buscarCliente(idCliente);

			this.vwDelClient.setText(cliente);
		}

		private void btModificarCliente_Click(object sender, EventArgs e) {
			if ((this.vwModClient.cbListaClientes.SelectedItem == null && this.vwModClient.Text == "Ej: 123456789") || 
				this.vwModClient.txtCedula.Text == null ||
				this.vwModClient.txtCedula.Text == "") {
				MessageBox.Show("Seleccione un cliente.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}
			if (!verifyFormat(this.vwModClient.txtCedula.Text, "space") ||
				!verifyFormat(this.vwModClient.txtCedula.Text, "")      ||
				this.vwModClient.txtCedula.Text.Length < 9) {
				MessageBox.Show("Cédula: Formato incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			if (!verifyFormat(this.vwModClient.txtNombre.Text, "space") ||
				!verifyFormat(this.vwModClient.txtNombre.Text, "text")) {
				MessageBox.Show("Nombre: Formato incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			if (!verifyFormat(this.vwModClient.txtPais.Text, "space") ||
				!verifyFormat(this.vwModClient.txtPais.Text, "text")) {
				MessageBox.Show("Pais Natal: Formato incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			if (!verifyFormat(this.vwModClient.txtTelefono.Text, "space") ||
				!verifyFormat(this.vwModClient.txtTelefono.Text, "") ||
				this.vwModClient.txtTelefono.Text.Length < 8) {
				MessageBox.Show("Télefono: Formato incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			if (!verifyFormat(this.vwModClient.txtEmail.Text, "space")) {
				MessageBox.Show("Correo Electrónico: Formato incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			if (this.vwModClient.txtNombre.Text == "Ej: Eyden Su Díaz" &&
				this.vwModClient.txtPais.Text == "Ej: Costa Rica" &&
				this.vwModClient.txtTelefono.Text == "Ej: 88888888" &&
				this.vwModClient.txtEmail.Text == "Ej: ejemplo@gmail.com") {
				MessageBox.Show("Error: Modifique al menos 1 espacio", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			Clientes clientManager = new Clientes(bdHotel);
			int idCliente = Convert.ToInt32(this.vwModClient.txtCedula.Text);
			string nombre = this.vwModClient.txtNombre.Text;
			string pais = this.vwModClient.txtPais.Text;
			string telefono = this.vwModClient.txtTelefono.Text;
			string email = this.vwModClient.txtEmail.Text;

			if (nombre != "Ej: Eyden Su Díaz") {
				clientManager.modificarCliente(idCliente, nombre, "", -1, "");
			}
			if (pais != "Ej: Costa Rica") {
				clientManager.modificarCliente(idCliente, "", pais, -1, "");
			}
			if (telefono != "Ej: 88888888") {
				clientManager.modificarCliente(idCliente, "", "", Convert.ToInt32(telefono), "");
			}
			if (email != "Ej: ejemplo@gmail.com") {
				clientManager.modificarCliente(idCliente, "", "", -1, email);
			}
			MessageBox.Show("Cliente modificado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
			this.vwModClient.clearText();
			this.vwModClient.readOnly();
			this.vwModClient.cbListaClientes.SelectedIndex = -1;
		}

		private void btEliminarCliente_Click(object sender, EventArgs e) {

			if (this.vwDelClient.txtCedula.Text == "" || this.vwDelClient.txtCedula.Text == null) {
				MessageBox.Show("Seleccione un cliente.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}
			string idCliente = this.vwDelClient.txtCedula.Text;
			string nombre = this.vwDelClient.txtNombre.Text;
			DialogResult resultado = MessageBox.Show("¿Estás seguro que deseas eliminar al Cliente "+ nombre + " ?", "Confirmar", MessageBoxButtons.YesNo);
			if (resultado == DialogResult.No) {
				return;
			}
			Clientes clientManager = new Clientes(bdHotel);
			clientManager.eliminarCliente(Convert.ToInt32(idCliente));
			MessageBox.Show("Cliente eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
			this.vwDelClient.clearText();
			this.vwDelClient.txtBuscar.Text = "";
			this.vwDelClient.cbListaClientes.SelectedIndex = -1;
		}



		//#################################################################################//
		//################################################################################//


		private void txtBuscar_Listener(object sender, KeyPressEventArgs e) {
			if (e.KeyChar == (char) Keys.Enter) {
				if (this.vwModClient != null &&  this.vwModClient.Visible) {
					btBuscarCliente_Mod_Click(sender, EventArgs.Empty);
				} else {
					btBuscarCliente_Del_Click(sender, EventArgs.Empty);
				}

				e.Handled = true;
			}
		}

		public void cbListaClientes_Mod_Listener(object sender, EventArgs e) {
			if (this.vwModClient.cbListaClientes.SelectedItem == null) {
				return;
			}
			Clientes clientManager = new Clientes(bdHotel);
			string idCliente = (this.vwModClient.cbListaClientes.Text).Substring(0,9);
			string[] cliente = clientManager.buscarCliente(idCliente);

			this.vwModClient.setText(cliente);

			List<string> clientList = clientManager.getClientes();
			if (clientList == null || clientList.Count == 0) {
				MessageBox.Show("No hay clientes para modificar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}
			this.vwModClient.cbListaClientes.Items.AddRange(clientList.ToArray());
			this.vwModClient.enWrite();
		}

		public void cbListaClientes_Del_Listener(object sender, EventArgs e) {
			if (this.vwDelClient.cbListaClientes.SelectedItem == null) {
				return;
			}
			Clientes clientManager = new Clientes(bdHotel);
			string idCliente = (this.vwDelClient.cbListaClientes.Text).Substring(0,9);
			string[] cliente = clientManager.buscarCliente(idCliente);

			this.vwDelClient.setText(cliente);

			List<string> clientList = clientManager.getClientes();
			if (clientList == null || clientList.Count == 0) {
				MessageBox.Show("No hay clientes para modificar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}
			this.vwDelClient.cbListaClientes.Items.AddRange(clientList.ToArray());
		}

		private bool verifyFormat(string pText, string verify) {
			bool flag = false;
			if (pText == null || pText.Length == 0) {
				return false;
			}
			if (verify == "space") {
				for (int i = 0; i < pText.Length; i++) {
					if (flag && pText[i] == ' ') {
						return false;
					} else if (pText[i] == ' ') {
						flag = true;
					} else {
						flag = false;
					}
				}
			} else if (verify == "text") {
				for (int i = 0; i < pText.Length; i++) {
					if (isNum(pText[i])) {
						return false;
					}
				}
			} else {
				for (int i = 0; i < pText.Length; i++) {
					if (!isNum(pText[i])) {
						return false;
					}
				}
			}
			return true;
		}

		private bool isNum(char pCharacter) {
			return char.IsDigit(pCharacter);
		}



		  //////                    ⬆⬆⬆⬆⬆ CÓDIGO EYDEN FIN ⬆⬆⬆⬆⬆                   /////////
		 /////////////////////////////////////////////////////////////////////////////////
		//*****************************************************************************//


		






		///////////////////////////////////////////////////////////////////////////////
		///////                       CÓDIGO JOSE ANDRÉS                      ////////

		public void agregarReserva(VistaAgregarReservas pVistaAgregarReservas) {
			this.reservas = pVistaAgregarReservas;
			this.reservas.FormClosed += cerrarVentana;
			this.reservas.Show();
			reservas.botonResgitrarInformacion.Click += AgregarReserva_Aux;
			reservas.botonRegistrarCliente.Click += AgregarCliente;
			reservas.botonChechIn.Click += AgregarCheckIn;
			reservas.botonCheckOut.Click += AgregarCheckOut;
			reservas.botonVerPrecio.Click += VerPrecioTotal;



		}

		private void VerPrecioTotal(object sender, EventArgs e) {
			if (reservas.textIdentificacion.Text == "" || reservas.textCheckIn.Text == "" || reservas.textCheckOut.Text == "" || reservas.comboBoxDescuntos.SelectedItem == null) {
				MessageBox.Show("Credenciales Incompletas. Por favor, Llene todos los espacios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				bdHotel.Close();
				return;
			}

			try {
				Convert.ToInt32(reservas.textIdentificacion.Text);
			} catch (Exception ex) {
				MessageBox.Show("Error al validar el idCliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				bdHotel.Close();
				return;

			} finally {
				bdHotel.Close();
			}
			//////////////////Validacion idCliente existente/////////////////////////////////////////////////////////////
			bdHotel.Open();
			SqlCommand obtenerIds = new SqlCommand("SELECT idCliente FROM Cliente WHERE (idCliente = @idCliente)", bdHotel);
			obtenerIds.Parameters.AddWithValue("@idCliente", Convert.ToInt32(reservas.textIdentificacion.Text));
			DateTime fechaCheckIn_Aux = fechaCheckIn;


			var id = obtenerIds.ExecuteScalar();
			bdHotel.Close();

			if (id == DBNull.Value) {
				MessageBox.Show("Cliente no registrado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				bdHotel.Close();
				return;
			}

			////////////////////////Validacion precioByhabitacion//////////////////////////
			SqlCommand validarPrecioHabitacion = new SqlCommand("SELECT precio FROM Habitacion WHERE(tipo = @tipo)", bdHotel);
			validarPrecioHabitacion.Parameters.AddWithValue("@tipo", reservas.comboBoxHabitacion.SelectedItem.ToString());
			double precio = 0;
			bdHotel.Open();
			double precioHabitacion = Convert.ToDouble(validarPrecioHabitacion.ExecuteScalar());
			bdHotel.Close();
			/////////////////////////////////////Validacion dias////////////////////////////////////////////////////////////////////////////
			while (fechaCheckIn_Aux != fechaCheckOut.AddDays(1)) {
				////Temporadas altas
				if (fechaCheckIn_Aux >= DateTime.Parse("01/06/2024") && fechaCheckIn_Aux <= DateTime.Parse("31/08/2024")) {
					precio += precioHabitacion;

				} else if (fechaCheckIn_Aux >= DateTime.Parse("24/03/2024") && fechaCheckIn_Aux <= DateTime.Parse("7/04/2024")) {
					precio += precioHabitacion;
				} else if (fechaCheckIn_Aux >= DateTime.Parse("20/12/2024") && fechaCheckIn_Aux <= DateTime.Parse("15/01/2025")) {
					precio += precioHabitacion;
				}
				  ////Temporadas medias
				  else if (fechaCheckIn_Aux >= DateTime.Parse("01/09/2024") && fechaCheckIn_Aux <= DateTime.Parse("20/10/2024")) {
					precio += precioHabitacion - precioHabitacion * 0.3;
				} else if (fechaCheckIn_Aux >= DateTime.Parse("16/01/2024") && fechaCheckIn_Aux <= DateTime.Parse("08/02/2024")) {
					precio += precioHabitacion - precioHabitacion * 0.3;
				} else {
					precio += precioHabitacion - precioHabitacion * 0.4;
				}
				fechaCheckIn_Aux = fechaCheckIn_Aux.AddDays(1);

			}

			/////////////////////////////////////COMBOBOX DE DESCUENTOS////////////////////////////////////////////////////////////////////////////
			bdHotel.Open();
			SqlCommand AgregarDescuentos = new SqlCommand("SELECT COUNT(idCliente) FROM Reserva WHERE descuentoAplicado != 1 and idCliente = @idCliente", bdHotel);
			AgregarDescuentos.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);
			int countadorDescuentos = Convert.ToInt32(AgregarDescuentos.ExecuteScalar());
			bdHotel.Close();

			if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "5% de descuento." && countadorDescuentos >= 5) {
				precio -= (precio * 0.05);
			} else if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "10% de descuento." && countadorDescuentos >= 6) {
				precio -= precio * 0.1;

			} else if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "Noche gratis." && countadorDescuentos >= 10) {
				fechaCheckOut = fechaCheckOut.AddDays(1);
			} else if (reservas.comboBoxDescuntos.SelectedItem.ToString() != "No aplicar descuento.") {
				MessageBox.Show("No tienes suficientes puntos para obtener este descuento", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			reservas.labelPrecioTotal.Text = "Precio total: " + precio.ToString();
		}
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		private void AgregarReserva_Aux(object sender, EventArgs e) {

			if (reservas.textIdentificacion.Text == "" || reservas.textCheckIn.Text == "" || reservas.textCheckOut.Text == "" || reservas.comboBoxDescuntos.SelectedItem == null) {
				MessageBox.Show("Credenciales Incompletas. Por favor, Llene todos los espacios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				bdHotel.Close();
				return;
			}
			try {
				Convert.ToInt32(reservas.textIdentificacion.Text);
			} catch (Exception ex) {
				MessageBox.Show("Error al validar el idCliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				bdHotel.Close();
				return;
			} finally {
				bdHotel.Close();
			}

			//////////////////Validacion idCliente existente/////////////////////////////////////////////////////////////
			bdHotel.Open();
			SqlCommand obtenerIds = new SqlCommand("SELECT idCliente FROM Cliente WHERE (idCliente = @idCliente)", bdHotel);
			obtenerIds.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);

			var id = obtenerIds.ExecuteScalar();
			bdHotel.Close();

			if (id == null && id == DBNull.Value) {
				MessageBox.Show("Cliente no registrado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			DateTime fechaCheckIn_Aux = fechaCheckIn;

			////////////////////////Validacion precioByhabitacion//////////////////////////
			SqlCommand validarPrecioHabitacion = new SqlCommand("SELECT precio FROM Habitacion WHERE(tipo = @tipo)", bdHotel);
			validarPrecioHabitacion.Parameters.AddWithValue("@tipo", reservas.comboBoxHabitacion.SelectedItem.ToString());
			double precio = 0;
			bdHotel.Open();
			double precioHabitacion = Convert.ToDouble(validarPrecioHabitacion.ExecuteScalar());
			bdHotel.Close();

			/////////////////////////////////////Validacion dias////////////////////////////////////////////////////////////////////////////
			while (fechaCheckIn_Aux != fechaCheckOut.AddDays(1)) {
				////Temporadas altas
				if (fechaCheckIn_Aux >= DateTime.Parse("01/06/2024") && fechaCheckIn_Aux <= DateTime.Parse("31/08/2024")) {
					precio += precioHabitacion;

				} else if (fechaCheckIn_Aux >= DateTime.Parse("24/03/2024") && fechaCheckIn_Aux <= DateTime.Parse("7/04/2024")) {
					precio += precioHabitacion;
				} else if (fechaCheckIn_Aux >= DateTime.Parse("20/12/2024") && fechaCheckIn_Aux <= DateTime.Parse("15/01/2025")) {
					precio += precioHabitacion;
				}
				  ////Temporadas medias
				  else if (fechaCheckIn_Aux >= DateTime.Parse("01/09/2024") && fechaCheckIn_Aux <= DateTime.Parse("20/10/2024")) {
					precio += precioHabitacion - precioHabitacion * 0.3;
				} else if (fechaCheckIn_Aux >= DateTime.Parse("16/01/2024") && fechaCheckIn_Aux <= DateTime.Parse("08/02/2024")) {
					precio += precioHabitacion - precioHabitacion * 0.3;
				} else {
					precio += precioHabitacion - precioHabitacion * 0.4;
				}
				fechaCheckIn_Aux = fechaCheckIn_Aux.AddDays(1);

			}

			/////////////////////////////////////COMBOBOX DE DESCUENTOS////////////////////////////////////////////////////////////////////////////

			SqlCommand AgregarDescuentos = new SqlCommand("SELECT COUNT(idCliente) FROM Reserva WHERE descuentoAplicado != 1 and idCliente = @idCliente", bdHotel);
			AgregarDescuentos.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);
			bdHotel.Open();
			int countadorDescuentos = Convert.ToInt32(AgregarDescuentos.ExecuteScalar());


			if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "5% de descuento." && countadorDescuentos >= 5) {
				int contador = 0;
				SqlCommand SelectsIdReservas = new SqlCommand("SELECT idReserva FROM Reserva WHERE idCliente = @idCliente", bdHotel);
				SelectsIdReservas.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);
				SqlDataReader idReservas = SelectsIdReservas.ExecuteReader();
				List<int> ids = new List<int>();
				while (idReservas.Read()) {
					ids.Add(idReservas.GetInt32(0));
				}
				bdHotel.Close();
				foreach (int idactual in ids) {
					if (contador == 5) {

						break;
					}
					bdHotel.Open();
					SqlCommand updateBit = new SqlCommand("UPDATE Reserva SET descuentoAplicado = 1 WHERE idReserva = @idReserva", bdHotel);
					updateBit.Parameters.AddWithValue("@idReserva", idactual);
					updateBit.ExecuteNonQuery();
					bdHotel.Close();
					contador++;
				}
				precio -= (precio * 0.05);
			} else if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "10% de descuento." && countadorDescuentos >= 6) {

				int contador = 0;
				SqlCommand SelectsIdReservas = new SqlCommand("SELECT idReserva FROM Reserva WHERE idCliente = @idCliente", bdHotel);
				SelectsIdReservas.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);
				SqlDataReader idReservas = SelectsIdReservas.ExecuteReader();
				List<int> ids = new List<int>();
				while (idReservas.Read()) {
					ids.Add(idReservas.GetInt32(0));
				}
				bdHotel.Close();
				foreach (int idactual in ids) {
					if (contador == 6) {

						break;
					}
					bdHotel.Open();
					SqlCommand updateBit = new SqlCommand("UPDATE Reserva SET descuentoAplicado = 1 WHERE idReserva = @idReserva", bdHotel);
					updateBit.Parameters.AddWithValue("@idReserva", idactual);
					updateBit.ExecuteNonQuery();
					bdHotel.Close();
					contador++;
				}
				precio -= precio * 0.1;

			} else if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "Noche gratis." && countadorDescuentos >= 10) {

				int contador = 0;
				SqlCommand SelectsIdReservas = new SqlCommand("SELECT idReserva FROM Reserva WHERE idCliente = @idCliente", bdHotel);
				SelectsIdReservas.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);
				SqlDataReader idReservas = SelectsIdReservas.ExecuteReader();
				List<int> ids = new List<int>();
				while (idReservas.Read()) {
					ids.Add(idReservas.GetInt32(0));
				}
				bdHotel.Close();
				foreach (int idactual in ids) {
					if (contador == 10) {

						break;
					}
					bdHotel.Open();
					SqlCommand updateBit = new SqlCommand("UPDATE Reserva SET descuentoAplicado = 1 WHERE idReserva = @idReserva", bdHotel);
					updateBit.Parameters.AddWithValue("@idReserva", idactual);
					updateBit.ExecuteNonQuery();
					bdHotel.Close();
					contador++;
				}
				fechaCheckOut = fechaCheckOut.AddDays(1);
			} else if (reservas.comboBoxDescuntos.SelectedItem.ToString() != "No aplicar descuento.") {
				MessageBox.Show("No tienes suficientes puntos para obtener este descuento", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			bdHotel.Close();

			try {
				bdHotel.Open();
				SqlCommand encontrarIdHabitacion = new SqlCommand("SELECT idHabitacion FROM Habitacion WHERE(tipo = @tipo)", bdHotel);
				encontrarIdHabitacion.Parameters.AddWithValue("@tipo", reservas.comboBoxHabitacion.SelectedItem.ToString());
				int idHabitacion = Convert.ToInt32(encontrarIdHabitacion.ExecuteScalar());

				int idReserva = 0;

				SqlCommand encontrarMaxIdReserva = new SqlCommand("SELECT MAX(idReserva) FROM Reserva", bdHotel);
				if (encontrarMaxIdReserva.ExecuteScalar() != DBNull.Value) {
					idReserva = Convert.ToInt32(encontrarMaxIdReserva.ExecuteScalar());
				}

				SqlCommand register = new SqlCommand("INSERT INTO Reserva VALUES (@idReserva, @idCliente,'ACTIVO', @fechaEntrada, @fechaSalida, @idHabitacion, 0, @precioTotal)", bdHotel);
				register.Parameters.AddWithValue("@idReserva", idReserva + 1);
				register.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);
				register.Parameters.AddWithValue("@fechaEntrada", fechaCheckIn.ToString("MM-dd-yyyy"));
				register.Parameters.AddWithValue("@fechaSalida", fechaCheckOut.ToString("MM-dd-yyyy"));

				register.Parameters.AddWithValue("@idHabitacion", idHabitacion);
				register.Parameters.AddWithValue("@precioTotal", precio);
				int rowsAffected = register.ExecuteNonQuery();
				MessageBox.Show("Reserva agregada exitosamente.");
			} catch (Exception ex) {
				MessageBox.Show("Error al agregar la reserva: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			} finally {
				bdHotel.Close();
			}
		}

		private void AgregarCliente(object sender, EventArgs e) {
			if (reservas.textIdentificacion.Text == "") {
				MessageBox.Show("Credenciales Incompletas. Por favor, Llene todos los espacios");
				return;
			}

			bdHotel.Open();
			SqlCommand login = new SqlCommand("SELECT idCliente FROM Cliente WHERE (idCliente = @idCliente)", bdHotel);
			login.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);

			/////////////////////////////////////COMBOBOX DE HABITACIONES//////////////////////////////////////////////////////////////////////////////

			try {
				SqlCommand agregarHabitacion = new SqlCommand("SELECT DISTINCT tipo FROM Habitacion", bdHotel);
				SqlDataReader reader = agregarHabitacion.ExecuteReader();
				//Limpiamos primero el comboBox
				reservas.comboBoxHabitacion.Items.Clear();

				//Agrega los elementos al comboBox
				while (reader.Read()) {
					reservas.comboBoxHabitacion.Items.Add(reader["tipo"].ToString());
				}

				//Cierra el lector y la coneccion
				reader.Close();

			} catch (Exception ex) {
				MessageBox.Show("ERROR: No se cargaron los tipos de habitaciones: " + ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
				bdHotel.Close();
			}

			if (reservas.comboBoxHabitacion.SelectedIndex == -1) {
				MessageBox.Show("por favor, selecciones una habitacion disponible", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				bdHotel.Close();
				return;
			}
			bdHotel.Close();
		}

		private void AgregarCheckIn(object sender, EventArgs e) {
			fechaCheckIn = reservas.monthCalendario.SelectionRange.Start;
			reservas.textCheckIn.Text = fechaCheckIn.ToShortDateString();

		}

		private void AgregarCheckOut(object sender, EventArgs e) {
			fechaCheckOut = reservas.monthCalendario.SelectionRange.Start;
			reservas.textCheckOut.Text = fechaCheckOut.ToShortDateString();

		}

		public void borrarReservas(VistaBorrarReservas pVistaBorrarReservas) {
			this.ajustes = pVistaBorrarReservas;
			this.ajustes.Show();
			ajustes.botonVerReservas.Click += verReservas;
			//ajustes.botonRegresar.Click += regresar
			ajustes.botonBorrarReservas.Click += borrarReservas_Aux;

		}
		private void verReservas(object sender, EventArgs e) {

			try {
				bdHotel.Open();
				/////ComboBox VerReservas:
				MessageBox.Show("Ya puedes ver la informacion de reservas: ", "Confirmacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
				SqlCommand verReservas = new SqlCommand("SELECT DISTINCT idReserva, idCliente, estadoReserva FROM Reserva ", bdHotel);
				SqlDataReader reader = verReservas.ExecuteReader();
				//Limpiamos primero el comboBox
				ajustes.comboBoxVerReservas.Items.Clear();

				//Agrega los elementos al comboBox
				while (reader.Read()) {
					string item = reader["idReserva"].ToString() + " | " +
								  reader["idCliente"].ToString() + " | " +
								  reader["estadoReserva"].ToString();
					ajustes.comboBoxVerReservas.Items.Add(item);
				}

				//Cierra el lector y la coneccion
				reader.Close();
				bdHotel.Close();
			} catch (Exception ex) {
				MessageBox.Show("ERROR: No se cargaron los tipos de reserva: " + ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

			} finally {
				bdHotel.Close();
			}
		}
		private void borrarReservas_Aux(object sender, EventArgs e) {
			if (ajustes.comboBoxVerReservas.Text == "") {
				MessageBox.Show("Seleccione una reserva a eliminar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			if (ajustes.comboBoxVerReservas.SelectedItem == null) {
				MessageBox.Show("Seleccione una reserva a eliminar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			try {
				// Abre la conexión a la base de datos
				bdHotel.Open();

				// Obtiene el valor seleccionado del ComboBox
				string selectedItem = ajustes.comboBoxVerReservas.SelectedItem.ToString();

				// Divide el valor seleccionado en sus partes (idReserva, idCliente, estadoReserva)
				string[] parts = selectedItem.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
				string idReserva = parts[0].Trim();
				string idCliente = parts[1].Trim();
				string estadoReserva = parts[2].Trim();
				if (estadoReserva == "ACTIVO") {
					MessageBox.Show("Reserva no eliminada, estado a 'ACTIVO'", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
					return;
				}

				// Verifica si la reserva aún existe en la base de datos
				SqlCommand verificarReserva = new SqlCommand("SELECT Count(idReserva, idCliente, estadoReserva) FROM Reserva WHERE idReserva = @idReserva AND idCliente = @idCliente AND estadoReserva = @estadoReserva", bdHotel);
				verificarReserva.Parameters.AddWithValue("@idReserva", idReserva);
				verificarReserva.Parameters.AddWithValue("@idCliente", idCliente);
				verificarReserva.Parameters.AddWithValue("@estadoReserva", estadoReserva);
				int rowCount = (int)verificarReserva.ExecuteScalar();

				if (rowCount == 0) {
					MessageBox.Show("La reserva seleccionada ya ha sido eliminada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					ajustes.comboBoxVerReservas.Text = "";
					ajustes.comboBoxVerReservas.Items.Clear();

					return;
				}

				// Construye la consulta SQL para eliminar la reserva
				string query = "DELETE FROM Reserva WHERE idReserva = @idReserva AND idCliente = @idCliente AND estadoReserva = @estadoReserva";

				// Crea y configura el comando SQL
				SqlCommand eliminarReserva = new SqlCommand(query, bdHotel);
				eliminarReserva.Parameters.AddWithValue("@idReserva", idReserva);
				eliminarReserva.Parameters.AddWithValue("@idCliente", idCliente);
				eliminarReserva.Parameters.AddWithValue("@estadoReserva", estadoReserva);

				// Ejecuta la consulta SQL
				int rowsAffected = eliminarReserva.ExecuteNonQuery();

				// Verifica si se eliminó correctamente la reserva
				if (rowsAffected > 0) {
					MessageBox.Show("Reserva eliminada correctamente", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
					ajustes.comboBoxVerReservas.Items.Clear();
					ajustes.comboBoxVerReservas.Text = "";
				} else {
					MessageBox.Show("No se pudo eliminar la reserva", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					ajustes.comboBoxVerReservas.Items.Clear();
					ajustes.comboBoxVerReservas.Text = "";
				}
			} catch (Exception ex) {
				MessageBox.Show("Error al intentar eliminar la reserva: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			} finally {
				// Cierra la conexión a la base de datos
				bdHotel.Close();
			}
		}

		public void ajusteReserva(VistaEstadoReserva pVistaEstadoReserva) {
			this.estadoReserva = pVistaEstadoReserva;
			this.estadoReserva.FormClosed += cerrarVentana;
			this.estadoReserva.Show();

			estadoReserva.botonAplicarCambioEstadoReserva.Click += ajusteReserva_Aux;
			estadoReserva.botonVerReserva.Click += verReservasEstado;
			//estadoReserva.botonRegresar.Click += regresarReservaEstado;
		}
		public void ajusteReserva_Aux(object sender, EventArgs e) {
			if (estadoReserva.textNumReserva.Text == "") {

				MessageBox.Show("Credenciales Incompletas. Por favor, Llene todos los espacios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				bdHotel.Close();
				return;
			}
			if (!estadoReserva.textNumReserva.Text.All(char.IsDigit)) {
				MessageBox.Show("El número de reserva solo puede contener caracteres numéricos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				bdHotel.Close();
				return;
			}
			try {
				Convert.ToInt32(estadoReserva.textNumReserva.Text);
			} catch (Exception ex) {
				MessageBox.Show("Error al validar el idReserva: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				bdHotel.Close();
				return;
			} finally {
				bdHotel.Close();
			}
			//////////////////Validacion idReserva existente/////////////////////////////////////////////////////////////
			bdHotel.Open();
			SqlCommand obtenerIdReserva = new SqlCommand("SELECT idReserva FROM Reserva WHERE (idReserva = @idReserva)", bdHotel);
			obtenerIdReserva.Parameters.AddWithValue("@idReserva", Convert.ToInt32(estadoReserva.textNumReserva.Text));
			///fechaCheckIn_Aux2
			DateTime fechaCheckIn_Aux2 = DateTime.Now;


			var idReserva = obtenerIdReserva.ExecuteScalar();
			bdHotel.Close();

			if (idReserva == DBNull.Value) {
				MessageBox.Show("Reserva no registrada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				bdHotel.Close();
				return;
			}


			/////////////////////////////////////Validacion dias////////////////////////////////////////////////////////////////////////////

			// Verificar si fechaCheckIn_Aux2 no pasa de 2 días
			if ((fechaCheckIn_Aux2 - fechaCheckIn).TotalDays <= 2) {
				MessageBox.Show("Error: CANCELACION NO APLICABLE, ESTAS CANCELANDO FALTANDO 1 DIA O 2 PARA TU RESERVA.", "ERR0R", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}

			bdHotel.Open();
			SqlCommand cambiarEstadoReserva = new SqlCommand("UPDATE Reserva SET estadoReserva = 'Cancelado/Pendiente a borrar' WHERE idReserva = @idReserva", bdHotel);
			cambiarEstadoReserva.Parameters.AddWithValue("@idReserva", Convert.ToInt32(estadoReserva.textNumReserva.Text)); // Cambiar a idReserva
			cambiarEstadoReserva.ExecuteNonQuery(); // Ejecuta el comando para actualizar el estado


			try {
				int rowsAffected = cambiarEstadoReserva.ExecuteNonQuery(); // Ejecutar el comando para actualizar el estado
				if (rowsAffected > 0) {
					MessageBox.Show("CONFIRMACION: Se cambió el estado exitosamente.", "NOTICIA", MessageBoxButtons.OK, MessageBoxIcon.Information);
				} else {
					MessageBox.Show("No se encontró ninguna reserva con el ID proporcionado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
			} catch (Exception ex) {
				MessageBox.Show("ERROR: No se cambió el estado de la reserva: " + ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			} finally {
				bdHotel.Close();
			}



		}



		private void verReservasEstado(object sender, EventArgs e) {

			try {
				bdHotel.Open();
				/////ComboBox VerReservas:
				MessageBox.Show("Ya puedes ver la informacion de reservas: ", "Confirmacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
				SqlCommand verReservasEstado = new SqlCommand("SELECT DISTINCT idReserva, idCliente, estadoReserva,fechaEntrada FROM Reserva ", bdHotel);
				SqlDataReader reader = verReservasEstado.ExecuteReader();
				//Limpiamos primero el comboBox
				estadoReserva.comboBoxVerReservas2.Items.Clear();

				//Agrega los elementos al comboBox
				while (reader.Read()) {
					string item = reader["idReserva"].ToString() + " | " +
								  reader["idCliente"].ToString() + " | " +
								  reader["fechaEntrada"].ToString() + " | " +
								  reader["estadoReserva"].ToString();
					estadoReserva.comboBoxVerReservas2.Items.Add(item);
				}

				//Cierra el lector y la coneccion
				reader.Close();
				bdHotel.Close();
			} catch (Exception ex) {
				MessageBox.Show("ERROR: No se cargaron los tipos de reserva: " + ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

			} finally {
				bdHotel.Close();
			}
		}

		 ///////        ⬆⬆⬆⬆⬆  CÓDIGO JOSE FIN  ⬆⬆⬆⬆⬆        ////////
		///////////////////////////////////////////////////////////
	}
}
