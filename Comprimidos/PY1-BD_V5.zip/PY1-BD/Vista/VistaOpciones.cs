﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PY1_BD.Vista {
	public partial class VistaOpciones : Form {

		public Boolean esAdmin;
		private string active;
		public VistaOpciones(Boolean pEsAdmin) {
			this.esAdmin = pEsAdmin;
			this.active = null;
			
			InitializeComponent();
			this.btAdd.Visible = false;
			this.btMod.Visible = false;
			this.btDel.Visible = false;
		}

		public void setActive(String pActive) {
			this.active = pActive;
		}

		public String getActive() {
			return this.active;
		}
	}
}
