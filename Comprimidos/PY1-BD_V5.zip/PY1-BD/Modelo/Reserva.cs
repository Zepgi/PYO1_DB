﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using PY1_BD.Vista;


namespace PY1_BD.Modelo {
    public class Reserva{
        private SqlConnection bdHotel;
        public Reserva(SqlConnection pBdHotel){
            this.bdHotel = pBdHotel;
        }
        public void agregarReserva(int pIdReserva, int pIdCliente, string pEstadoReserva, string pFechaEntrada, string pFechaSalida, int pIdHabitacion, int pDescuentoAplicado, decimal pPrecioTotal) {
            int idReserva = pIdReserva;
            int idCliente = pIdCliente;
            string estadoReserva = pEstadoReserva;
            string fechaEntrada = pFechaEntrada;
            string fechaSalida = pFechaSalida;
            int idHabitacion = pIdHabitacion;
            int descuentoAplicado = pDescuentoAplicado;
            decimal precioTotal = pPrecioTotal;

            bdHotel.Open();
            SqlCommand addCl = new SqlCommand("INSERT INTO Reserva VALUES (@idReserva, @idCliente, @estadoReserva, @fechaEntrada, @fechaSalida, @idHabitacion, @descuentoAplicado, @precioTotal)", bdHotel);
            addCl.Parameters.AddWithValue("@idReserva", idReserva);
            addCl.Parameters.AddWithValue("@idCliente", idCliente);
            addCl.Parameters.AddWithValue("@estadoReserva", estadoReserva);
            addCl.Parameters.AddWithValue("@fechaEntrada", fechaEntrada);
            addCl.Parameters.AddWithValue("@fechaSalida", fechaSalida);
            addCl.Parameters.AddWithValue("@idHabitacion", idHabitacion);
            addCl.Parameters.AddWithValue("@descuentoAplicado",descuentoAplicado);
            addCl.Parameters.AddWithValue("@precioTotal", precioTotal);

            bdHotel.Close();
            return;
        }
    }
}
