﻿namespace PY1_BD.Vista
{
    partial class VistaGraficos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.logoImg = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.logoImg)).BeginInit();
            this.SuspendLayout();
            // 
            // logoImg
            // 
            this.logoImg.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.logoImg.BackColor = System.Drawing.Color.Transparent;
            this.logoImg.BackgroundImage = global::PY1_BD.Properties.Resources.Color;
            this.logoImg.Image = global::PY1_BD.Properties.Resources.Logo;
            this.logoImg.Location = new System.Drawing.Point(738, -3);
            this.logoImg.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.logoImg.Name = "logoImg";
            this.logoImg.Size = new System.Drawing.Size(146, 174);
            this.logoImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logoImg.TabIndex = 14;
            this.logoImg.TabStop = false;
            // 
            // VistaGraficos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(884, 761);
            this.Controls.Add(this.logoImg);
            this.Name = "VistaGraficos";
            this.Text = "VistaGraficos";
            ((System.ComponentModel.ISupportInitialize)(this.logoImg)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox logoImg;
    }
}