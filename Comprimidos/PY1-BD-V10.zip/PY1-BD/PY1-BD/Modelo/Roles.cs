﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PY1_BD.Modelo {
	internal class Roles {
		private SqlConnection bdHotel;
		public Roles(SqlConnection pBdHotel) {
			this.bdHotel = pBdHotel;
		}

		public List<string> getRoles() {
			List<string> roles = new List<string>();
			bdHotel.Open();
			SqlCommand selCl = new SqlCommand("SELECT idRol, nombreRol FROM Rol", bdHotel);
			SqlDataReader rolesReader = selCl.ExecuteReader();

			while (rolesReader.Read()) {
				roles.Add(rolesReader["nombreRol"].ToString());
			}
			bdHotel.Close();
			if (roles.Count == 0) {
				return null;
			}
			return roles;
		}

		public int buscarIdRol(string pNombre) {
			int idRol = -1;
			bdHotel.Open();
			SqlCommand selRol = new SqlCommand("SELECT idRol FROM Rol WHERE nombreRol = @nombreRol", bdHotel);
			selRol.Parameters.AddWithValue("@nombreRol", pNombre);
			object result = selRol.ExecuteScalar();

			if (result != null && result != DBNull.Value) {
				idRol = Convert.ToInt32(result);
			}
			bdHotel.Close();

			return idRol;
		}
	}
}
