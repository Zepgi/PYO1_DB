﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PY1_BD.Vista {
    public partial class VistaGrficos : Form {

        public SqlConnection bdHotel; 

        public VistaGrficos(SqlConnection pbdHotel) {
            this.bdHotel = pbdHotel;
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e) {

        }

        private void textBox2_TextChanged(object sender, EventArgs e) {

        }

        private void VistaGrficos_Load(object sender, EventArgs e) {
            // TODO: esta línea de código carga datos en la tabla 'hOTELKARPASDataSet1.Reserva' Puede moverla o quitarla según sea necesario.
            //his.reservaTableAdapter.Fill(this.hOTELKARPASDataSet1.Reserva);
            // TODO: esta línea de código carga datos en la tabla 'hOTELKARPASDataSet1.Cliente' Puede moverla o quitarla según sea necesario.
            //this.clienteTableAdapter.Fill(this.hOTELKARPASDataSet1.Cliente);

        }

        private void label1_Click(object sender, EventArgs e) {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) {

        }

        private void button2_Click(object sender, EventArgs e) {
            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-MSC89MI;Initial Catalog=HOTELKARPAS;Integrated Security=True")) {
                connection.Open();

                // Obtener el id de la habitación usando su nombre
                string habitacion = textBox1.Text;
                SqlCommand getIdHabitacion = new SqlCommand("SELECT idHabitacion FROM Habitacion WHERE tipo = @tipo", connection);
                getIdHabitacion.Parameters.AddWithValue("@tipo", habitacion);
                int idHabitacion = Convert.ToInt32(getIdHabitacion.ExecuteScalar());

                // Consultar las reservas para la habitación específica
                SqlCommand getReservas = new SqlCommand("SELECT idReserva, idCliente, estadoReserva, fechaEntrada, fechaSalida, idHabitacion, descuentoAplicado, precioTotal FROM Reserva WHERE idHabitacion = @idHabitacion", connection);
                getReservas.Parameters.AddWithValue("@idHabitacion", idHabitacion);

                // Ejecutar la consulta y cargar los resultados en un DataTable
                SqlDataAdapter adapter = new SqlDataAdapter(getReservas);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                // Mostrar los resultados en el DataGridView
                dataGridView1.DataSource = dt;
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            this.Dispose();
        }
    }
}
