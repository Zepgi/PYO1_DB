﻿using PY1_BD.Modelo;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PY1_BD.Vista {

        public partial class VistaReporteria : Form {

        public SqlConnection bdHotel;
        public VistaReporteria(SqlConnection pbdHotel) {
            this.bdHotel = pbdHotel;
            InitializeComponent();
        }

        private void label1_Click_1(object sender, EventArgs e) {

        }

        private void label2_Click(object sender, EventArgs e) {

        }

        private void textBox2_TextChanged(object sender, EventArgs e) {

        }

        private void label3_Click(object sender, EventArgs e) {

        }

        private void label4_Click(object sender, EventArgs e) {

        }

        private void textBox4_TextChanged(object sender, EventArgs e) {

        }

        private void label5_Click(object sender, EventArgs e) {

        }

        private void button2_Click(object sender, EventArgs e) {
            SqlConnection ne = new SqlConnection("Data Source=DESKTOP-MSC89MI;Initial Catalog=HOTELKARPAS;Integrated Security=True");
            ne.Open();
            SqlCommand ss = new SqlCommand("SELECT idReserva, idCliente, estadoReserva, fechaEntrada, fechaSalida, idHabitacion, descuentoAplicado, precioTotal FROM Reserva Where idCliente=@idCliente", ne);
            ss.Parameters.AddWithValue("idCliente", int.Parse(textReporteriaCliente.Text));
            SqlDataAdapter ad = new SqlDataAdapter(ss);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dataTablaReporteria.DataSource = dt;
        }

        private void BotonGrafig_Click(object sender, EventArgs e) {
            Form graficos= new VistaGrficos(new SqlConnection("Data Source=DESKTOP-MSC89MI;Initial Catalog=HOTELKARPAS;Integrated Security=True"));
            graficos.Show();
        }

        private void VistaReporteria_Load(object sender, EventArgs e) {
            // TODO: esta línea de código carga datos en la tabla 'hOTELKARPASDataSet11.Reserva' Puede moverla o quitarla según sea necesario.
            //this.reservaTableAdapter.Fill(this.hOTELKARPASDataSet11.Reserva);
            // TODO: esta línea de código carga datos en la tabla 'hOTELKARPASDataSet1.Reserva' Puede moverla o quitarla según sea necesario.
            //this.reservaTableAdapter.Fill(this.hOTELKARPASDataSet1.Reserva);

        }

        private void textBox3_TextChanged(object sender, EventArgs e) {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) {

        }

        private void button3_Click(object sender, EventArgs e) {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-MSC89MI;Initial Catalog=HOTELKARPAS;Integrated Security=True");
            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT idReserva, idCliente, estadoReserva, fechaEntrada, fechaSalida, idHabitacion, descuentoAplicado, precioTotal FROM Reserva", conn);
            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dataTablaReporteria.DataSource = dt;
        }

        private void button5_Click(object sender, EventArgs e) {
            SqlConnection an = new SqlConnection("Data Source=DESKTOP-MSC89MI;Initial Catalog=HOTELKARPAS;Integrated Security=True");
            an.Open();
            SqlCommand dmc = new SqlCommand("SELECT idReserva, idCliente, estadoReserva, fechaEntrada, fechaSalida, idHabitacion, descuentoAplicado, precioTotal FROM Reserva WHERE estadoReserva = 'Cancelado/Pendiente a borrar'", an);
            SqlDataAdapter arm = new SqlDataAdapter(dmc);
            DataTable st = new DataTable();
            arm.Fill(st);
            dataTablaReporteria.DataSource = st;
        }

        private void button4_Click(object sender, EventArgs e) {
            SqlConnection aa = new SqlConnection("Data Source=DESKTOP-MSC89MI;Initial Catalog=HOTELKARPAS;Integrated Security=True");
            aa.Open();
            SqlCommand dmz = new SqlCommand("SELECT TOP 1 idCliente, COUNT(idCliente) AS veces_repetido FROM Reserva GROUP BY idCliente ORDER BY COUNT(idCliente) DESC", aa);
            SqlDataAdapter gtr = new SqlDataAdapter(dmz);
            DataTable lw = new DataTable();
            gtr.Fill(lw);
            dataTablaReporteria.DataSource = lw;

        }

        private void textBox5_TextChanged(object sender, EventArgs e) {

        }

        private void button1_Click(object sender, EventArgs e) {
            this.Close();
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e) {

        }
    }
}
