﻿namespace PY1_BD.Vista {
    partial class VistaReporteria {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.botonReporteriaIngresar = new System.Windows.Forms.Button();
            this.textReporteriaCliente = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.reservaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hOTELKARPASDataSet1 = new PY1_BD.HOTELKARPASDataSet1();
            this.button1 = new System.Windows.Forms.Button();
            this.botonReporteriaReservas = new System.Windows.Forms.Button();
            this.botonReporteriaCancel = new System.Windows.Forms.Button();
            this.botonReporteriaTopClient = new System.Windows.Forms.Button();
            this.reservaTableAdapter = new PY1_BD.HOTELKARPASDataSet1TableAdapters.ReservaTableAdapter();
            this.reservaBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.hOTELKARPASDataSet11 = new PY1_BD.HOTELKARPASDataSet1();
            this.dataTablaReporteria = new System.Windows.Forms.DataGridView();
            this.textReporteriaHabitacion = new System.Windows.Forms.TextBox();
            this.botonReporteriaHabitacion = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.reservaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hOTELKARPASDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservaBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hOTELKARPASDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTablaReporteria)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Info;
            this.label1.Location = new System.Drawing.Point(92, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(262, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "Todas las reservas";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Info;
            this.label2.Location = new System.Drawing.Point(58, 142);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(257, 34);
            this.label2.TabIndex = 2;
            this.label2.Text = "Reservas por cliente";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Info;
            this.label3.Location = new System.Drawing.Point(372, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(359, 34);
            this.label3.TabIndex = 4;
            this.label3.Text = "Cancelaciones Realizadas";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Info;
            this.label4.Location = new System.Drawing.Point(779, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(505, 34);
            this.label4.TabIndex = 7;
            this.label4.Text = "Cliente con mas reservas Realizadas";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // botonReporteriaIngresar
            // 
            this.botonReporteriaIngresar.BackColor = System.Drawing.Color.LemonChiffon;
            this.botonReporteriaIngresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonReporteriaIngresar.Location = new System.Drawing.Point(360, 235);
            this.botonReporteriaIngresar.Name = "botonReporteriaIngresar";
            this.botonReporteriaIngresar.Size = new System.Drawing.Size(49, 41);
            this.botonReporteriaIngresar.TabIndex = 9;
            this.botonReporteriaIngresar.Text = "✔";
            this.botonReporteriaIngresar.UseVisualStyleBackColor = false;
            this.botonReporteriaIngresar.Click += new System.EventHandler(this.button2_Click);
            // 
            // textReporteriaCliente
            // 
            this.textReporteriaCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textReporteriaCliente.Location = new System.Drawing.Point(63, 235);
            this.textReporteriaCliente.Multiline = true;
            this.textReporteriaCliente.Name = "textReporteriaCliente";
            this.textReporteriaCliente.Size = new System.Drawing.Size(198, 41);
            this.textReporteriaCliente.TabIndex = 10;
            this.textReporteriaCliente.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Info;
            this.label5.Location = new System.Drawing.Point(58, 176);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(296, 45);
            this.label5.TabIndex = 11;
            this.label5.Text = "Ingrese la cedula del cliente:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // reservaBindingSource
            // 
            this.reservaBindingSource.DataMember = "Reserva";
            this.reservaBindingSource.DataSource = this.hOTELKARPASDataSet1;
            // 
            // hOTELKARPASDataSet1
            // 
            this.hOTELKARPASDataSet1.DataSetName = "HOTELKARPASDataSet1";
            this.hOTELKARPASDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Turquoise;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1069, 755);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 35);
            this.button1.TabIndex = 14;
            this.button1.Text = "Atras";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // botonReporteriaReservas
            // 
            this.botonReporteriaReservas.BackColor = System.Drawing.Color.LemonChiffon;
            this.botonReporteriaReservas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonReporteriaReservas.Location = new System.Drawing.Point(144, 64);
            this.botonReporteriaReservas.Name = "botonReporteriaReservas";
            this.botonReporteriaReservas.Size = new System.Drawing.Size(129, 32);
            this.botonReporteriaReservas.TabIndex = 10;
            this.botonReporteriaReservas.Text = "Actualizar";
            this.botonReporteriaReservas.UseVisualStyleBackColor = false;
            this.botonReporteriaReservas.Click += new System.EventHandler(this.button3_Click);
            // 
            // botonReporteriaCancel
            // 
            this.botonReporteriaCancel.BackColor = System.Drawing.Color.LemonChiffon;
            this.botonReporteriaCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonReporteriaCancel.Location = new System.Drawing.Point(487, 64);
            this.botonReporteriaCancel.Name = "botonReporteriaCancel";
            this.botonReporteriaCancel.Size = new System.Drawing.Size(125, 32);
            this.botonReporteriaCancel.TabIndex = 16;
            this.botonReporteriaCancel.Text = "Actualizar";
            this.botonReporteriaCancel.UseVisualStyleBackColor = false;
            this.botonReporteriaCancel.Click += new System.EventHandler(this.button5_Click);
            // 
            // botonReporteriaTopClient
            // 
            this.botonReporteriaTopClient.BackColor = System.Drawing.Color.LemonChiffon;
            this.botonReporteriaTopClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonReporteriaTopClient.Location = new System.Drawing.Point(913, 88);
            this.botonReporteriaTopClient.Name = "botonReporteriaTopClient";
            this.botonReporteriaTopClient.Size = new System.Drawing.Size(125, 32);
            this.botonReporteriaTopClient.TabIndex = 17;
            this.botonReporteriaTopClient.Text = "Actualizar";
            this.botonReporteriaTopClient.UseVisualStyleBackColor = false;
            this.botonReporteriaTopClient.Click += new System.EventHandler(this.button4_Click);
            // 
            // reservaTableAdapter
            // 
            this.reservaTableAdapter.ClearBeforeFill = true;
            // 
            // reservaBindingSource1
            // 
            this.reservaBindingSource1.DataMember = "Reserva";
            this.reservaBindingSource1.DataSource = this.hOTELKARPASDataSet11;
            // 
            // hOTELKARPASDataSet11
            // 
            this.hOTELKARPASDataSet11.DataSetName = "HOTELKARPASDataSet1";
            this.hOTELKARPASDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataTablaReporteria
            // 
            this.dataTablaReporteria.AutoGenerateColumns = false;
            this.dataTablaReporteria.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataTablaReporteria.DataSource = this.reservaBindingSource;
            this.dataTablaReporteria.Location = new System.Drawing.Point(29, 301);
            this.dataTablaReporteria.Name = "dataTablaReporteria";
            this.dataTablaReporteria.RowHeadersWidth = 51;
            this.dataTablaReporteria.RowTemplate.Height = 24;
            this.dataTablaReporteria.Size = new System.Drawing.Size(1166, 436);
            this.dataTablaReporteria.TabIndex = 18;
            this.dataTablaReporteria.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // textReporteriaHabitacion
            // 
            this.textReporteriaHabitacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textReporteriaHabitacion.Location = new System.Drawing.Point(878, 236);
            this.textReporteriaHabitacion.Multiline = true;
            this.textReporteriaHabitacion.Name = "textReporteriaHabitacion";
            this.textReporteriaHabitacion.Size = new System.Drawing.Size(160, 28);
            this.textReporteriaHabitacion.TabIndex = 21;
            // 
            // botonReporteriaHabitacion
            // 
            this.botonReporteriaHabitacion.BackColor = System.Drawing.Color.LemonChiffon;
            this.botonReporteriaHabitacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonReporteriaHabitacion.Location = new System.Drawing.Point(1070, 226);
            this.botonReporteriaHabitacion.Name = "botonReporteriaHabitacion";
            this.botonReporteriaHabitacion.Size = new System.Drawing.Size(59, 50);
            this.botonReporteriaHabitacion.TabIndex = 20;
            this.botonReporteriaHabitacion.Text = "✔";
            this.botonReporteriaHabitacion.UseVisualStyleBackColor = false;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Info;
            this.label6.Location = new System.Drawing.Point(796, 187);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(399, 34);
            this.label6.TabIndex = 19;
            this.label6.Text = "Seleccione la Habitacion a buscar";
            // 
            // VistaReporteria
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1221, 802);
            this.Controls.Add(this.textReporteriaHabitacion);
            this.Controls.Add(this.botonReporteriaHabitacion);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dataTablaReporteria);
            this.Controls.Add(this.botonReporteriaTopClient);
            this.Controls.Add(this.botonReporteriaCancel);
            this.Controls.Add(this.botonReporteriaReservas);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textReporteriaCliente);
            this.Controls.Add(this.botonReporteriaIngresar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "VistaReporteria";
            this.Text = "Hotel Karpas";
            this.Load += new System.EventHandler(this.VistaReporteria_Load);
            ((System.ComponentModel.ISupportInitialize)(this.reservaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hOTELKARPASDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservaBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hOTELKARPASDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTablaReporteria)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.Button botonReporteriaIngresar;
        public System.Windows.Forms.TextBox textReporteriaCliente;
        private System.Windows.Forms.Label label5;
        private HOTELKARPASDataSet1 hOTELKARPASDataSet1;
        private System.Windows.Forms.BindingSource reservaBindingSource;
        private HOTELKARPASDataSet1TableAdapters.ReservaTableAdapter reservaTableAdapter;
        public System.Windows.Forms.DataGridViewTextBoxColumn temporadaDataGridViewTextBoxColumn;
        public System.Windows.Forms.Button button1;
        public System.Windows.Forms.Button botonReporteriaReservas;
        public System.Windows.Forms.Button botonReporteriaCancel;
        public System.Windows.Forms.Button botonReporteriaTopClient;
        private HOTELKARPASDataSet1 hOTELKARPASDataSet11;
        private System.Windows.Forms.BindingSource reservaBindingSource1;
        public System.Windows.Forms.DataGridView dataTablaReporteria;
        public System.Windows.Forms.TextBox textReporteriaHabitacion;
        public System.Windows.Forms.Button botonReporteriaHabitacion;
        private System.Windows.Forms.Label label6;
    }
}