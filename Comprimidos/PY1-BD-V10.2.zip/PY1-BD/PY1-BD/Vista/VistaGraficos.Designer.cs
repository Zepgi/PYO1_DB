﻿namespace PY1_BD.Vista
{
    partial class VistaGraficos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.logoImg = new System.Windows.Forms.PictureBox();
            this.botonGraficaRecepcionista = new System.Windows.Forms.Button();
            this.botonGraficaTopFechas = new System.Windows.Forms.Button();
            this.Graficas = new System.Windows.Forms.Label();
            this.chartGraficosGenerales = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.botonRegresar = new System.Windows.Forms.Button();
            this.botonGraficaClientes = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.logoImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartGraficosGenerales)).BeginInit();
            this.SuspendLayout();
            // 
            // logoImg
            // 
            this.logoImg.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.logoImg.BackColor = System.Drawing.Color.Transparent;
            this.logoImg.BackgroundImage = global::PY1_BD.Properties.Resources.Color;
            this.logoImg.Image = global::PY1_BD.Properties.Resources.Logo;
            this.logoImg.Location = new System.Drawing.Point(738, -3);
            this.logoImg.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.logoImg.Name = "logoImg";
            this.logoImg.Size = new System.Drawing.Size(146, 174);
            this.logoImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logoImg.TabIndex = 14;
            this.logoImg.TabStop = false;
            // 
            // botonGraficaRecepcionista
            // 
            this.botonGraficaRecepcionista.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonGraficaRecepcionista.Location = new System.Drawing.Point(311, 167);
            this.botonGraficaRecepcionista.Name = "botonGraficaRecepcionista";
            this.botonGraficaRecepcionista.Size = new System.Drawing.Size(113, 26);
            this.botonGraficaRecepcionista.TabIndex = 15;
            this.botonGraficaRecepcionista.Text = "Ver";
            this.botonGraficaRecepcionista.UseVisualStyleBackColor = true;
            // 
            // botonGraficaTopFechas
            // 
            this.botonGraficaTopFechas.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonGraficaTopFechas.Location = new System.Drawing.Point(536, 167);
            this.botonGraficaTopFechas.Name = "botonGraficaTopFechas";
            this.botonGraficaTopFechas.Size = new System.Drawing.Size(113, 26);
            this.botonGraficaTopFechas.TabIndex = 17;
            this.botonGraficaTopFechas.Text = "Ver";
            this.botonGraficaTopFechas.UseVisualStyleBackColor = true;
            // 
            // Graficas
            // 
            this.Graficas.AutoSize = true;
            this.Graficas.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Graficas.ForeColor = System.Drawing.Color.LemonChiffon;
            this.Graficas.Location = new System.Drawing.Point(344, 52);
            this.Graficas.Name = "Graficas";
            this.Graficas.Size = new System.Drawing.Size(147, 38);
            this.Graficas.TabIndex = 18;
            this.Graficas.Text = "Graficas";
            // 
            // chartGraficosGenerales
            // 
            chartArea1.Name = "ChartArea1";
            this.chartGraficosGenerales.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chartGraficosGenerales.Legends.Add(legend1);
            this.chartGraficosGenerales.Location = new System.Drawing.Point(230, 304);
            this.chartGraficosGenerales.Name = "chartGraficosGenerales";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chartGraficosGenerales.Series.Add(series1);
            this.chartGraficosGenerales.Size = new System.Drawing.Size(313, 300);
            this.chartGraficosGenerales.TabIndex = 19;
            // 
            // botonRegresar
            // 
            this.botonRegresar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonRegresar.Location = new System.Drawing.Point(759, 719);
            this.botonRegresar.Name = "botonRegresar";
            this.botonRegresar.Size = new System.Drawing.Size(113, 30);
            this.botonRegresar.TabIndex = 20;
            this.botonRegresar.Text = "Regresar";
            this.botonRegresar.UseVisualStyleBackColor = true;
            this.botonRegresar.Click += new System.EventHandler(this.botonRegresar_Click);
            // 
            // botonGraficaClientes
            // 
            this.botonGraficaClientes.Location = new System.Drawing.Point(109, 171);
            this.botonGraficaClientes.Name = "botonGraficaClientes";
            this.botonGraficaClientes.Size = new System.Drawing.Size(75, 23);
            this.botonGraficaClientes.TabIndex = 21;
            this.botonGraficaClientes.Text = "button1";
            this.botonGraficaClientes.UseVisualStyleBackColor = true;
            // 
            // VistaGraficos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(884, 761);
            this.Controls.Add(this.botonGraficaClientes);
            this.Controls.Add(this.botonRegresar);
            this.Controls.Add(this.chartGraficosGenerales);
            this.Controls.Add(this.Graficas);
            this.Controls.Add(this.botonGraficaTopFechas);
            this.Controls.Add(this.botonGraficaRecepcionista);
            this.Controls.Add(this.logoImg);
            this.Name = "VistaGraficos";
            this.Text = "VistaGraficos";
            this.Load += new System.EventHandler(this.VistaGraficos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.logoImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartGraficosGenerales)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox logoImg;
        public System.Windows.Forms.Button botonGraficaRecepcionista;
        public System.Windows.Forms.Button botonGraficaTopFechas;
        private System.Windows.Forms.Label Graficas;
        public System.Windows.Forms.DataVisualization.Charting.Chart chartGraficosGenerales;
        public System.Windows.Forms.Button botonRegresar;
        public System.Windows.Forms.Button botonGraficaClientes;
    }
}