﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PY1_BD.Modelo {
	internal class Cuentas {
		private SqlConnection bdHotel;
		public Cuentas(SqlConnection pBdHotel) {
			this.bdHotel = pBdHotel;
		}

		public void agregarCuenta(int pIdUsuario, string pContrasena) {
			int idUsuario = pIdUsuario;
			string contrasena = pContrasena; 
			int idCuenta = 0;
			bdHotel.Open();
			SqlCommand cmd = new SqlCommand("SELECT MAX(idCuenta) FROM Cuenta", bdHotel);
			if (cmd.ExecuteScalar() != DBNull.Value) {
				idCuenta = Convert.ToInt32(cmd.ExecuteScalar()) + 1;
			}
			bdHotel.Close();

			bdHotel.Open();
			SqlCommand addCuenta = new SqlCommand("INSERT INTO Cuenta VALUES (@idUsuario, @idCuenta, @pasword)", bdHotel);
			addCuenta.Parameters.AddWithValue("@idUsuario", idUsuario);
			addCuenta.Parameters.AddWithValue("@idCuenta", idCuenta);
			addCuenta.Parameters.AddWithValue("@pasword", contrasena);
			addCuenta.ExecuteNonQuery();
			bdHotel.Close();
		}
	}
}
