﻿using PY1_BD.Vista;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PY1_BD.Control
{
	public class Controlador {

        public VistaLogin vista;
        public DateTime fechaCheckOut;
        public DateTime fechaCheckIn;
        public VistaAgregarReservas reservas;
        private static readonly SqlConnection bdHotel = new SqlConnection("Data Source = VARGAS2001; Initial Catalog = HOTELKARPAS; Integrated Security = True; Encrypt=False");
        public Controlador(VistaLogin pVista) {
			this.reservas = null;
            this.vista = pVista;

			this.vista.btIngresar.Click += iniciarSesion;
		}

		private void iniciarSesion(object sender, EventArgs e) {
			if (vista.txtCedula.Text == "" || vista.txtContrasena.Text == "") {
				MessageBox.Show("Credenciales Incompletas. Por favor, Llene todos los espacios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			bdHotel.Open();
			SqlCommand login = new SqlCommand("SELECT idCuenta FROM Cuenta WHERE (idUsuario = @idUsuario AND pasword = @password)", bdHotel);
			login.Parameters.AddWithValue("@idUsuario", vista.txtCedula.Text);
			login.Parameters.AddWithValue("@password", vista.txtContrasena.Text);

			try {
				var result = login.ExecuteScalar();
				if (result != null && result != DBNull.Value) {

					vista.Hide();

					SqlCommand rol = new SqlCommand("SELECT idRol FROM Usuario WHERE idUsuario = @idUsuario", bdHotel);
					rol.Parameters.AddWithValue("@idUsuario", vista.txtCedula.Text);
					int numRol = Convert.ToInt32(rol.ExecuteScalar());
					
					if (numRol == 1) {
						VistaAministrador vistaAdmin = new VistaAministrador();
						vistaAdmin.Show();

					} else {
						VistaRecepcionista vistaRecep = new VistaRecepcionista();
						vistaRecep.Show();
					}


				} else {
					MessageBox.Show("Credenciales incorrectas. Por favor, inténtalo de nuevo.");
				}
			} catch (Exception ex) {
				Console.WriteLine("Error: " + ex.Message);
			}
			bdHotel.Close();
		}
		public void agregarReserva(VistaAgregarReservas pVistaAgregarReservas){
			this.reservas = pVistaAgregarReservas;
			this.reservas.Show();
            reservas.botonResgitrarInformacion.Click += AgregarReserva_Aux;
			reservas.botonRegistrarCliente.Click += AgregarCliente;
            reservas.botonChechIn.Click += AgregarCheckIn;
            reservas.botonCheckOut.Click += AgregarCheckOut;
            reservas.botonVerPrecio.Click += VerPrecioTotal;



        }


        private void VerPrecioTotal(object sender, EventArgs e) 
        {
            if (reservas.textIdentificacion.Text == "" || reservas.textCheckIn.Text == "" || reservas.textCheckOut.Text == "" || reservas.comboBoxDescuntos.SelectedItem == null)
            {
                MessageBox.Show("Credenciales Incompletas. Por favor, Llene todos los espacios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
                return;
            }

            try
            {
                Convert.ToInt32(reservas.textIdentificacion.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al validar el idCliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
                return;
                
            }
            finally
            {
                bdHotel.Close();
            }
            //////////////////Validacion idCliente existente/////////////////////////////////////////////////////////////
            bdHotel.Open();
            SqlCommand obtenerIds = new SqlCommand("SELECT idCliente FROM Cliente WHERE (idCliente = @idCliente)", bdHotel);
            obtenerIds.Parameters.AddWithValue("@idCliente",Convert.ToInt32( reservas.textIdentificacion.Text));
            DateTime fechaCheckIn_Aux = fechaCheckIn;

           
            var id = obtenerIds.ExecuteScalar();
            bdHotel.Close();

            if (id == DBNull.Value)
            {
                MessageBox.Show("Cliente no registrado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
                return;
            }

            

            ////////////////////////Validacion precioByhabitacion//////////////////////////
            SqlCommand validarPrecioHabitacion = new SqlCommand("SELECT precio FROM Habitacion WHERE(tipo = @tipo)", bdHotel);
            validarPrecioHabitacion.Parameters.AddWithValue("@tipo", reservas.comboBoxHabitacion.SelectedItem.ToString());
            double precio = 0;
            bdHotel.Open();
            double precioHabitacion = Convert.ToDouble(validarPrecioHabitacion.ExecuteScalar());
            bdHotel.Close();
            /////////////////////////////////////Validacion dias////////////////////////////////////////////////////////////////////////////
            while (fechaCheckIn_Aux != fechaCheckOut.AddDays(1))
            {
                ////Temporadas altas
                if (fechaCheckIn_Aux >= DateTime.Parse("01/06/2024") && fechaCheckIn_Aux <= DateTime.Parse("31/08/2024"))
                {
                    precio += precioHabitacion;

                }
                else if (fechaCheckIn_Aux >= DateTime.Parse("24/03/2024") && fechaCheckIn_Aux <= DateTime.Parse("7/04/2024"))
                {
                    precio += precioHabitacion;
                }
                else if (fechaCheckIn_Aux >= DateTime.Parse("20/12/2024") && fechaCheckIn_Aux <= DateTime.Parse("15/01/2025"))
                {
                    precio += precioHabitacion;
                }
                ////Temporadas medias
                else if (fechaCheckIn_Aux >= DateTime.Parse("01/09/2024") && fechaCheckIn_Aux <= DateTime.Parse("20/10/2024"))
                {
                    precio += precioHabitacion - precioHabitacion * 0.3;
                }
                else if (fechaCheckIn_Aux >= DateTime.Parse("16/01/2024") && fechaCheckIn_Aux <= DateTime.Parse("08/02/2024"))
                {
                    precio += precioHabitacion - precioHabitacion * 0.3;
                }
                else
                {
                    precio += precioHabitacion - precioHabitacion * 0.4;
                }
                 fechaCheckIn_Aux = fechaCheckIn_Aux.AddDays(1);

            }


            /////////////////////////////////////COMBOBOX DE DESCUENTOS////////////////////////////////////////////////////////////////////////////
            bdHotel.Open();
            SqlCommand AgregarDescuentos = new SqlCommand("SELECT COUNT(idCliente) FROM Reserva WHERE descuentoAplicado != 1 and idCliente = @idCliente", bdHotel);
            AgregarDescuentos.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);
            int countadorDescuentos = Convert.ToInt32(AgregarDescuentos.ExecuteScalar());
            bdHotel.Close();

            if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "5% de descuento." && countadorDescuentos >= 5)
            {
                precio -= (precio * 0.05);
            }
            else if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "10% de descuento." && countadorDescuentos >= 6)
            {
                precio -= precio * 0.1;

            }
            else if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "Noche gratis." && countadorDescuentos >= 10)
            {
                fechaCheckOut = fechaCheckOut.AddDays(1);
            }
            else if (reservas.comboBoxDescuntos.SelectedItem.ToString() != "No aplicar descuento.")
            {
                MessageBox.Show("No tienes suficientes puntos para obtener este descuento", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            reservas.labelPrecioTotal.Text = "Precio total: " + precio.ToString();
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void AgregarReserva_Aux(object sender, EventArgs e)
        {
          
            if (reservas.textIdentificacion.Text == "" || reservas.textCheckIn.Text == "" || reservas.textCheckOut.Text == "" || reservas.comboBoxDescuntos.SelectedItem == null)
            {
                MessageBox.Show("Credenciales Incompletas. Por favor, Llene todos los espacios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
                return;
            }
            try
            {
                Convert.ToInt32(reservas.textIdentificacion.Text);
            }
            catch (Exception ex)
            { 
             MessageBox.Show("Error al validar el idCliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
                return;
            }
            finally
            {
                bdHotel.Close();
            }

            //////////////////Validacion idCliente existente/////////////////////////////////////////////////////////////
            bdHotel.Open();
            SqlCommand obtenerIds = new SqlCommand("SELECT idCliente FROM Cliente WHERE (idCliente = @idCliente)", bdHotel);
            obtenerIds.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);

            var id = obtenerIds.ExecuteScalar();
            bdHotel.Close();

            if (id == null && id == DBNull.Value) {
                MessageBox.Show("Cliente no registrado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            DateTime fechaCheckIn_Aux = fechaCheckIn;

           
            ////////////////////////Validacion precioByhabitacion//////////////////////////
            SqlCommand validarPrecioHabitacion = new SqlCommand("SELECT precio FROM Habitacion WHERE(tipo = @tipo)", bdHotel);
            validarPrecioHabitacion.Parameters.AddWithValue("@tipo", reservas.comboBoxHabitacion.SelectedItem.ToString());
            double precio = 0;
            bdHotel.Open();
            double precioHabitacion = Convert.ToDouble(validarPrecioHabitacion.ExecuteScalar());
            bdHotel.Close();

            /////////////////////////////////////Validacion dias////////////////////////////////////////////////////////////////////////////
            while (fechaCheckIn_Aux != fechaCheckOut.AddDays(1))
            {
                ////Temporadas altas
               if(fechaCheckIn_Aux >= DateTime.Parse("01/06/2024") && fechaCheckIn_Aux <= DateTime.Parse("31/08/2024"))
                {
                    precio += precioHabitacion;
                    
                }
                else if (fechaCheckIn_Aux >= DateTime.Parse("24/03/2024") && fechaCheckIn_Aux <= DateTime.Parse("7/04/2024"))
                {
                    precio += precioHabitacion;
                }
                else if (fechaCheckIn_Aux >= DateTime.Parse("20/12/2024") && fechaCheckIn_Aux <= DateTime.Parse("15/01/2025"))
                {
                    precio += precioHabitacion;
                }
               ////Temporadas medias
                else if (fechaCheckIn_Aux >= DateTime.Parse("01/09/2024") && fechaCheckIn_Aux <= DateTime.Parse("20/10/2024"))
                {
                    precio += precioHabitacion - precioHabitacion * 0.3;
                }
                else if (fechaCheckIn_Aux >= DateTime.Parse("16/01/2024") && fechaCheckIn_Aux <= DateTime.Parse("08/02/2024"))
                {
                    precio += precioHabitacion - precioHabitacion*0.3;
                }
                else
                {
                    precio += precioHabitacion - precioHabitacion * 0.4;
                }
                fechaCheckIn_Aux = fechaCheckIn_Aux.AddDays(1);

            }


            /////////////////////////////////////COMBOBOX DE DESCUENTOS////////////////////////////////////////////////////////////////////////////
            
            SqlCommand AgregarDescuentos = new SqlCommand("SELECT COUNT(idCliente) FROM Reserva WHERE descuentoAplicado != 1 and idCliente = @idCliente", bdHotel);
            AgregarDescuentos.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);
            bdHotel.Open();
            int countadorDescuentos = Convert.ToInt32(AgregarDescuentos.ExecuteScalar());
            bdHotel.Close();

            if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "5% de descuento." && countadorDescuentos >= 5)
            {
                precio -= (precio * 0.05);
            }
            else if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "10% de descuento." && countadorDescuentos >= 6 ) 
            {
                precio -= precio * 0.1;

            }else if (reservas.comboBoxDescuntos.SelectedItem.ToString() == "Noche gratis." && countadorDescuentos >= 10)
            {
                fechaCheckOut = fechaCheckOut.AddDays(1) ;
            }
            else if(reservas.comboBoxDescuntos.SelectedItem.ToString() != "No aplicar descuento.")
            {
                MessageBox.Show("No tienes suficientes puntos para obtener este descuento", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                bdHotel.Open();
                SqlCommand encontrarIdHabitacion = new SqlCommand("SELECT idHabitacion FROM Habitacion WHERE(tipo = @tipo)", bdHotel);
                encontrarIdHabitacion.Parameters.AddWithValue("@tipo", reservas.comboBoxHabitacion.SelectedItem.ToString());
                int idHabitacion = Convert.ToInt32(encontrarIdHabitacion.ExecuteScalar());

                int idReserva = 0;

                SqlCommand encontrarMaxIdReserva = new SqlCommand("SELECT MAX(idReserva) FROM Reserva", bdHotel);
                if(encontrarMaxIdReserva.ExecuteScalar() != DBNull.Value)
                {
                    idReserva = Convert.ToInt32(encontrarMaxIdReserva.ExecuteScalar());
                }
               

         

                SqlCommand register = new SqlCommand("INSERT INTO Reserva VALUES (@idReserva, @idCliente,'ACTIVO', @fechaEntrada, @fechaSalida, @idHabitacion, 0, @precioTotal)", bdHotel);
                register.Parameters.AddWithValue("@idReserva", idReserva+1);
                register.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);
                register.Parameters.AddWithValue("@fechaEntrada", fechaCheckIn.ToString("MM-dd-yyyy"));
                register.Parameters.AddWithValue("@fechaSalida", fechaCheckOut.ToString("MM-dd-yyyy"));

                register.Parameters.AddWithValue("@idHabitacion", idHabitacion); 
                register.Parameters.AddWithValue("@precioTotal", precio);
                int rowsAffected = register.ExecuteNonQuery();
                MessageBox.Show("Reserva agregada exitosamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al agregar la reserva: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bdHotel.Close();
            }
        }


        private void AgregarCliente(object sender, EventArgs e) {
            if (reservas.textIdentificacion.Text == "")
            {
                MessageBox.Show("Credenciales Incompletas. Por favor, Llene todos los espacios");
                return;
            }


            bdHotel.Open();
            SqlCommand login = new SqlCommand("SELECT idCliente FROM Cliente WHERE (idCliente = @idCliente)", bdHotel);
            login.Parameters.AddWithValue("@idCliente", reservas.textIdentificacion.Text);

  

            
            /////////////////////////////////////COMBOBOX DE HABITACIONES//////////////////////////////////////////////////////////////////////////////

            try
            {


                SqlCommand agregarHabitacion = new SqlCommand("SELECT DISTINCT tipo FROM Habitacion", bdHotel);
                SqlDataReader reader = agregarHabitacion.ExecuteReader();
                //Limpiamos primero el comboBox
                reservas.comboBoxHabitacion.Items.Clear();

                //Agrega los elementos al comboBox
                while (reader.Read())
                {
                    reservas.comboBoxHabitacion.Items.Add(reader["tipo"].ToString());
                }

                //Cierra el lector y la coneccion
                reader.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: No se cargaron los tipos de habitaciones: " + ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
            }

            if (reservas.comboBoxHabitacion.SelectedIndex == -1)
            {
                MessageBox.Show("por favor, selecciones una habitacion disponible", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bdHotel.Close();
                return;
            }
            bdHotel.Close();



        }
        private void AgregarCheckIn(object sender, EventArgs e) {
            fechaCheckIn = reservas.monthCalendario.SelectionRange.Start;
            reservas.textCheckIn.Text = fechaCheckIn.ToShortDateString();
          
        }

        private void AgregarCheckOut(object sender, EventArgs e)
        {
            fechaCheckOut = reservas.monthCalendario.SelectionRange.Start;
            reservas.textCheckOut.Text = fechaCheckOut.ToShortDateString();

        }







    }
	

}
