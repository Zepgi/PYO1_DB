﻿namespace PY1_BD
{
    partial class VistaAministrador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.label1 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.botonReservas = new System.Windows.Forms.Button();
			this.botonClientes = new System.Windows.Forms.Button();
			this.botonReporteria = new System.Windows.Forms.Button();
			this.botonEditarReservas = new System.Windows.Forms.Button();
			this.botoPersonal = new System.Windows.Forms.Button();
			this.botonEstadosReserva = new System.Windows.Forms.Button();
			this.botonRegresar = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label1.Location = new System.Drawing.Point(236, 37);
			this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(568, 52);
			this.label1.TabIndex = 0;
			this.label1.Text = "Opciones de administrador";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(39, 150);
			this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(275, 29);
			this.label3.TabIndex = 2;
			this.label3.Text = "Agregar y ver reservas";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.Location = new System.Drawing.Point(39, 260);
			this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(310, 29);
			this.label4.TabIndex = 3;
			this.label4.Text = "Crear y modificar clientes";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.Location = new System.Drawing.Point(109, 380);
			this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(137, 29);
			this.label5.TabIndex = 4;
			this.label5.Text = "Reporteria";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.Location = new System.Drawing.Point(685, 150);
			this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(189, 29);
			this.label6.TabIndex = 5;
			this.label6.Text = "Editar reservas";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.Location = new System.Drawing.Point(635, 380);
			this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(331, 29);
			this.label7.TabIndex = 6;
			this.label7.Text = "Administracion de personal";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.Location = new System.Drawing.Point(649, 268);
			this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(312, 29);
			this.label8.TabIndex = 7;
			this.label8.Text = "Editar estados de reserva";
			// 
			// botonReservas
			// 
			this.botonReservas.BackColor = System.Drawing.Color.SaddleBrown;
			this.botonReservas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.botonReservas.ForeColor = System.Drawing.Color.White;
			this.botonReservas.Location = new System.Drawing.Point(128, 199);
			this.botonReservas.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.botonReservas.Name = "botonReservas";
			this.botonReservas.Size = new System.Drawing.Size(100, 41);
			this.botonReservas.TabIndex = 8;
			this.botonReservas.Text = "Ir";
			this.botonReservas.UseVisualStyleBackColor = false;
			// 
			// botonClientes
			// 
			this.botonClientes.BackColor = System.Drawing.Color.SaddleBrown;
			this.botonClientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.botonClientes.ForeColor = System.Drawing.Color.White;
			this.botonClientes.Location = new System.Drawing.Point(128, 315);
			this.botonClientes.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.botonClientes.Name = "botonClientes";
			this.botonClientes.Size = new System.Drawing.Size(100, 41);
			this.botonClientes.TabIndex = 9;
			this.botonClientes.Text = "Ir";
			this.botonClientes.UseVisualStyleBackColor = false;
			// 
			// botonReporteria
			// 
			this.botonReporteria.BackColor = System.Drawing.Color.SaddleBrown;
			this.botonReporteria.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.botonReporteria.ForeColor = System.Drawing.Color.White;
			this.botonReporteria.Location = new System.Drawing.Point(128, 427);
			this.botonReporteria.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.botonReporteria.Name = "botonReporteria";
			this.botonReporteria.Size = new System.Drawing.Size(100, 42);
			this.botonReporteria.TabIndex = 10;
			this.botonReporteria.Text = "Ir";
			this.botonReporteria.UseVisualStyleBackColor = false;
			// 
			// botonEditarReservas
			// 
			this.botonEditarReservas.BackColor = System.Drawing.Color.SaddleBrown;
			this.botonEditarReservas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.botonEditarReservas.ForeColor = System.Drawing.Color.White;
			this.botonEditarReservas.Location = new System.Drawing.Point(729, 199);
			this.botonEditarReservas.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.botonEditarReservas.Name = "botonEditarReservas";
			this.botonEditarReservas.Size = new System.Drawing.Size(100, 41);
			this.botonEditarReservas.TabIndex = 11;
			this.botonEditarReservas.Text = "Ir";
			this.botonEditarReservas.UseVisualStyleBackColor = false;
			// 
			// botoPersonal
			// 
			this.botoPersonal.BackColor = System.Drawing.Color.SaddleBrown;
			this.botoPersonal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.botoPersonal.ForeColor = System.Drawing.Color.White;
			this.botoPersonal.Location = new System.Drawing.Point(729, 430);
			this.botoPersonal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.botoPersonal.Name = "botoPersonal";
			this.botoPersonal.Size = new System.Drawing.Size(100, 41);
			this.botoPersonal.TabIndex = 12;
			this.botoPersonal.Text = "Ir";
			this.botoPersonal.UseVisualStyleBackColor = false;
			// 
			// botonEstadosReserva
			// 
			this.botonEstadosReserva.BackColor = System.Drawing.Color.SaddleBrown;
			this.botonEstadosReserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.botonEstadosReserva.ForeColor = System.Drawing.Color.White;
			this.botonEstadosReserva.Location = new System.Drawing.Point(729, 315);
			this.botonEstadosReserva.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.botonEstadosReserva.Name = "botonEstadosReserva";
			this.botonEstadosReserva.Size = new System.Drawing.Size(100, 41);
			this.botonEstadosReserva.TabIndex = 13;
			this.botonEstadosReserva.Text = "Ir";
			this.botonEstadosReserva.UseVisualStyleBackColor = false;
			// 
			// botonRegresar
			// 
			this.botonRegresar.BackColor = System.Drawing.Color.Red;
			this.botonRegresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.botonRegresar.ForeColor = System.Drawing.Color.White;
			this.botonRegresar.Location = new System.Drawing.Point(931, 506);
			this.botonRegresar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.botonRegresar.Name = "botonRegresar";
			this.botonRegresar.Size = new System.Drawing.Size(107, 59);
			this.botonRegresar.TabIndex = 14;
			this.botonRegresar.Text = "Regresar";
			this.botonRegresar.UseVisualStyleBackColor = false;
			// 
			// VistaAministrador
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Peru;
			this.ClientSize = new System.Drawing.Size(1097, 580);
			this.Controls.Add(this.botonRegresar);
			this.Controls.Add(this.botonEstadosReserva);
			this.Controls.Add(this.botoPersonal);
			this.Controls.Add(this.botonEditarReservas);
			this.Controls.Add(this.botonReporteria);
			this.Controls.Add(this.botonClientes);
			this.Controls.Add(this.botonReservas);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label1);
			this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.MinimizeBox = false;
			this.Name = "VistaAministrador";
			this.Text = "Hotel Karpas";
			this.Load += new System.EventHandler(this.VistaAministrador_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button botonReservas;
        private System.Windows.Forms.Button botonClientes;
        private System.Windows.Forms.Button botonReporteria;
        private System.Windows.Forms.Button botonEditarReservas;
        private System.Windows.Forms.Button botoPersonal;
        private System.Windows.Forms.Button botonEstadosReserva;
        private System.Windows.Forms.Button botonRegresar;
	}
}