﻿namespace PY1_BD.Vista
{
    partial class VistaRecepcionista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.botonSalir = new System.Windows.Forms.Button();
            this.botonEstadosReserva = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.botonReporteria = new System.Windows.Forms.Button();
            this.botonClientes = new System.Windows.Forms.Button();
            this.botonReservas = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(144, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(451, 39);
            this.label1.TabIndex = 30;
            this.label1.Text = "Opciones de recepcionista";
            // 
            // botonSalir
            // 
            this.botonSalir.BackColor = System.Drawing.Color.OrangeRed;
            this.botonSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonSalir.ForeColor = System.Drawing.Color.White;
            this.botonSalir.Location = new System.Drawing.Point(693, 385);
            this.botonSalir.Name = "botonSalir";
            this.botonSalir.Size = new System.Drawing.Size(86, 46);
            this.botonSalir.TabIndex = 29;
            this.botonSalir.Text = "Regresar";
            this.botonSalir.UseVisualStyleBackColor = false;
            // 
            // botonEstadosReserva
            // 
            this.botonEstadosReserva.BackColor = System.Drawing.Color.SaddleBrown;
            this.botonEstadosReserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonEstadosReserva.ForeColor = System.Drawing.Color.White;
            this.botonEstadosReserva.Location = new System.Drawing.Point(479, 139);
            this.botonEstadosReserva.Name = "botonEstadosReserva";
            this.botonEstadosReserva.Size = new System.Drawing.Size(75, 33);
            this.botonEstadosReserva.TabIndex = 28;
            this.botonEstadosReserva.Text = "Ir";
            this.botonEstadosReserva.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(419, 101);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(247, 24);
            this.label8.TabIndex = 27;
            this.label8.Text = "Editar estados de reserva";
            // 
            // botonReporteria
            // 
            this.botonReporteria.BackColor = System.Drawing.Color.SaddleBrown;
            this.botonReporteria.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonReporteria.ForeColor = System.Drawing.Color.White;
            this.botonReporteria.Location = new System.Drawing.Point(89, 326);
            this.botonReporteria.Name = "botonReporteria";
            this.botonReporteria.Size = new System.Drawing.Size(75, 34);
            this.botonReporteria.TabIndex = 26;
            this.botonReporteria.Text = "Ir";
            this.botonReporteria.UseVisualStyleBackColor = false;
            // 
            // botonClientes
            // 
            this.botonClientes.BackColor = System.Drawing.Color.SaddleBrown;
            this.botonClientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonClientes.ForeColor = System.Drawing.Color.White;
            this.botonClientes.Location = new System.Drawing.Point(89, 235);
            this.botonClientes.Name = "botonClientes";
            this.botonClientes.Size = new System.Drawing.Size(75, 33);
            this.botonClientes.TabIndex = 25;
            this.botonClientes.Text = "Ir";
            this.botonClientes.UseVisualStyleBackColor = false;
            // 
            // botonReservas
            // 
            this.botonReservas.BackColor = System.Drawing.Color.SaddleBrown;
            this.botonReservas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonReservas.ForeColor = System.Drawing.Color.White;
            this.botonReservas.Location = new System.Drawing.Point(89, 141);
            this.botonReservas.Name = "botonReservas";
            this.botonReservas.Size = new System.Drawing.Size(75, 33);
            this.botonReservas.TabIndex = 24;
            this.botonReservas.Text = "Ir";
            this.botonReservas.UseVisualStyleBackColor = false;
            this.botonReservas.Click += new System.EventHandler(this.botonReservas_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(75, 288);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 24);
            this.label5.TabIndex = 23;
            this.label5.Text = "Reporteria";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(22, 190);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(246, 24);
            this.label4.TabIndex = 22;
            this.label4.Text = "Crear y modificar clientes";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(221, 24);
            this.label3.TabIndex = 21;
            this.label3.Text = "Agregar y ver reservas";
            // 
            // xxx
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Peru;
            this.ClientSize = new System.Drawing.Size(808, 471);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.botonSalir);
            this.Controls.Add(this.botonEstadosReserva);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.botonReporteria);
            this.Controls.Add(this.botonClientes);
            this.Controls.Add(this.botonReservas);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.MinimizeBox = false;
            this.Name = "xxx";
            this.Text = "Hotel Karpas";
            this.Load += new System.EventHandler(this.xxx_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button botonSalir;
        private System.Windows.Forms.Button botonEstadosReserva;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button botonReporteria;
        private System.Windows.Forms.Button botonClientes;
        private System.Windows.Forms.Button botonReservas;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
    }
}