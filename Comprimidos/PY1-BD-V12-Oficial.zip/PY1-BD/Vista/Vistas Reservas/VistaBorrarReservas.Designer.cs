﻿namespace PY1_BD.Vista
{
    partial class VistaBorrarReservas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.botonRegresar = new System.Windows.Forms.Button();
            this.botonBorrarReservas = new System.Windows.Forms.Button();
            this.comboBoxVerReservas = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.botonVerReservas = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.logoImg = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.logoImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // botonRegresar
            // 
            this.botonRegresar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.botonRegresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.botonRegresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonRegresar.ForeColor = System.Drawing.Color.LemonChiffon;
            this.botonRegresar.Location = new System.Drawing.Point(21, 418);
            this.botonRegresar.Name = "botonRegresar";
            this.botonRegresar.Size = new System.Drawing.Size(108, 41);
            this.botonRegresar.TabIndex = 37;
            this.botonRegresar.Text = "Regresar";
            this.botonRegresar.UseVisualStyleBackColor = false;
            this.botonRegresar.Click += new System.EventHandler(this.botonRegresar_Click);
            // 
            // botonBorrarReservas
            // 
            this.botonBorrarReservas.BackColor = System.Drawing.Color.Black;
            this.botonBorrarReservas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.botonBorrarReservas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonBorrarReservas.ForeColor = System.Drawing.Color.LemonChiffon;
            this.botonBorrarReservas.Location = new System.Drawing.Point(347, 335);
            this.botonBorrarReservas.Name = "botonBorrarReservas";
            this.botonBorrarReservas.Size = new System.Drawing.Size(62, 34);
            this.botonBorrarReservas.TabIndex = 36;
            this.botonBorrarReservas.Text = "Borrar";
            this.botonBorrarReservas.UseVisualStyleBackColor = false;
            // 
            // comboBoxVerReservas
            // 
            this.comboBoxVerReservas.FormattingEnabled = true;
            this.comboBoxVerReservas.Location = new System.Drawing.Point(297, 230);
            this.comboBoxVerReservas.Name = "comboBoxVerReservas";
            this.comboBoxVerReservas.Size = new System.Drawing.Size(164, 21);
            this.comboBoxVerReservas.TabIndex = 35;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label2.Location = new System.Drawing.Point(307, 280);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(154, 22);
            this.label2.TabIndex = 34;
            this.label2.Text = "Borrar seleccion";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label1.Location = new System.Drawing.Point(242, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(325, 41);
            this.label1.TabIndex = 33;
            this.label1.Text = "Ajustes de reserva";
            // 
            // botonVerReservas
            // 
            this.botonVerReservas.BackColor = System.Drawing.Color.Black;
            this.botonVerReservas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.botonVerReservas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonVerReservas.ForeColor = System.Drawing.Color.LemonChiffon;
            this.botonVerReservas.Location = new System.Drawing.Point(347, 163);
            this.botonVerReservas.Name = "botonVerReservas";
            this.botonVerReservas.Size = new System.Drawing.Size(62, 41);
            this.botonVerReservas.TabIndex = 32;
            this.botonVerReservas.Text = "Ver";
            this.botonVerReservas.UseVisualStyleBackColor = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label7.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label7.Location = new System.Drawing.Point(317, 106);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(129, 22);
            this.label7.TabIndex = 31;
            this.label7.Text = "Ver reservas:";
            // 
            // logoImg
            // 
            this.logoImg.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.logoImg.BackColor = System.Drawing.Color.Transparent;
            this.logoImg.BackgroundImage = global::PY1_BD.Properties.Resources.Color;
            this.logoImg.Image = global::PY1_BD.Properties.Resources.Logo;
            this.logoImg.Location = new System.Drawing.Point(-8, -4);
            this.logoImg.Margin = new System.Windows.Forms.Padding(2);
            this.logoImg.Name = "logoImg";
            this.logoImg.Size = new System.Drawing.Size(211, 266);
            this.logoImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logoImg.TabIndex = 40;
            this.logoImg.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::PY1_BD.Properties.Resources.Color;
            this.pictureBox1.Location = new System.Drawing.Point(-8, -23);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(211, 545);
            this.pictureBox1.TabIndex = 41;
            this.pictureBox1.TabStop = false;
            // 
            // VistaBorrarReservas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(808, 471);
            this.Controls.Add(this.logoImg);
            this.Controls.Add(this.botonRegresar);
            this.Controls.Add(this.botonBorrarReservas);
            this.Controls.Add(this.comboBoxVerReservas);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.botonVerReservas);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pictureBox1);
            this.MinimizeBox = false;
            this.Name = "VistaBorrarReservas";
            this.Text = "Hotel Karpas";
            this.Load += new System.EventHandler(this.VistaAjustesReserva_Load);
            ((System.ComponentModel.ISupportInitialize)(this.logoImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button botonRegresar;
        public System.Windows.Forms.Button botonBorrarReservas;
        public System.Windows.Forms.ComboBox comboBoxVerReservas;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox logoImg;
        private System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.Button botonVerReservas;
    }
}