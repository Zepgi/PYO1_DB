﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PY1_BD.Vista {
    public partial class VistaGrficos : Form {

        public SqlConnection bdHotel; 

        public VistaGrficos(SqlConnection pbdHotel) {
            this.bdHotel = pbdHotel;
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e) {

        }

        private void textBox2_TextChanged(object sender, EventArgs e) {

        }

        private void VistaGrficos_Load(object sender, EventArgs e) {
            // TODO: esta línea de código carga datos en la tabla 'hOTELKARPASDataSet1.Reserva' Puede moverla o quitarla según sea necesario.
            //his.reservaTableAdapter.Fill(this.hOTELKARPASDataSet1.Reserva);
            // TODO: esta línea de código carga datos en la tabla 'hOTELKARPASDataSet1.Cliente' Puede moverla o quitarla según sea necesario.
            //this.clienteTableAdapter.Fill(this.hOTELKARPASDataSet1.Cliente);

        }

        private void label1_Click(object sender, EventArgs e) {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) {

        }
    }
}
