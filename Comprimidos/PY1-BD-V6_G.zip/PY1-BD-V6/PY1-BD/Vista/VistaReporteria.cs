﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PY1_BD.Vista {

        public partial class VistaReporteria : Form {

        public SqlConnection bdHotel;
        public VistaReporteria(SqlConnection pbdHotel) {
            this.bdHotel = pbdHotel;
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e) {

        }

        private void label1_Click_1(object sender, EventArgs e) {

        }

        private void label2_Click(object sender, EventArgs e) {

        }

        private void textBox2_TextChanged(object sender, EventArgs e) {

        }

        private void label3_Click(object sender, EventArgs e) {

        }

        private void label4_Click(object sender, EventArgs e) {

        }

        private void textBox4_TextChanged(object sender, EventArgs e) {

        }

        private void label5_Click(object sender, EventArgs e) {

        }

        private void button2_Click(object sender, EventArgs e) {

        }

        private void BotonGrafig_Click(object sender, EventArgs e) {
            Form graficos= new VistaGrficos(new SqlConnection("Data Source=DESKTOP-MSC89MI;Initial Catalog=HOTELKARPAS;Integrated Security=True"));
            graficos.Show();
        }

        private void VistaReporteria_Load(object sender, EventArgs e) {
            // TODO: esta línea de código carga datos en la tabla 'hOTELKARPASDataSet1.Reserva' Puede moverla o quitarla según sea necesario.
            //this.reservaTableAdapter.Fill(this.hOTELKARPASDataSet1.Reserva);

        }

        private void textBox3_TextChanged(object sender, EventArgs e) {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) {

        }
    }
}
