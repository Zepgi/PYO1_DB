﻿using PY1_BD.Modelo;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PY1_BD
{
    internal static class MainPruebas {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        /// 
        /*
        [STAThread]
        static void Main()
        {
            SqlConnection bd = new SqlConnection("Data Source=EYDEN;Initial Catalog=HOTELKARPAS;Integrated Security=True");
            Clientes c1 = new Clientes(bd);
            //c1.agregarCliente(703100722, "Eyden Su Díaz", "Costa Rica", 84035342, "esu@estudiantec.cr");
            c1.modificarCliente(703100722, null, null, 84035342, null);
        }
        */
        
    }
}
