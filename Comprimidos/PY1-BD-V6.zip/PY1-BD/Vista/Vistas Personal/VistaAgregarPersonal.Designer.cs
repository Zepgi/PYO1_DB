﻿namespace PY1_BD.Vista {
	partial class VistaAgregarPersonal {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.lbTitle = new System.Windows.Forms.Label();
			this.txtCedula = new System.Windows.Forms.TextBox();
			this.txtNombre = new System.Windows.Forms.TextBox();
			this.txtTelefono = new System.Windows.Forms.TextBox();
			this.txtEmail = new System.Windows.Forms.TextBox();
			this.btRegresar = new System.Windows.Forms.Button();
			this.lbCedula = new System.Windows.Forms.Label();
			this.lbNombre = new System.Windows.Forms.Label();
			this.lbBornDate = new System.Windows.Forms.Label();
			this.lbTelefono = new System.Windows.Forms.Label();
			this.lbEmail = new System.Windows.Forms.Label();
			this.logoImg = new System.Windows.Forms.PictureBox();
			this.btAgregar = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.lbAddress = new System.Windows.Forms.Label();
			this.lbGenero = new System.Windows.Forms.Label();
			this.lbRol = new System.Windows.Forms.Label();
			this.lbPassword = new System.Windows.Forms.Label();
			this.txtAddress = new System.Windows.Forms.TextBox();
			this.txtPassword = new System.Windows.Forms.TextBox();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.rbMas = new System.Windows.Forms.RadioButton();
			this.rbFem = new System.Windows.Forms.RadioButton();
			this.dtpBornDate = new System.Windows.Forms.DateTimePicker();
			((System.ComponentModel.ISupportInitialize)(this.logoImg)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// lbTitle
			// 
			this.lbTitle.AutoSize = true;
			this.lbTitle.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbTitle.ForeColor = System.Drawing.Color.LemonChiffon;
			this.lbTitle.Location = new System.Drawing.Point(397, 34);
			this.lbTitle.Name = "lbTitle";
			this.lbTitle.Size = new System.Drawing.Size(310, 27);
			this.lbTitle.TabIndex = 5;
			this.lbTitle.Text = "Información del Empleado";
			// 
			// txtCedula
			// 
			this.txtCedula.BackColor = System.Drawing.Color.White;
			this.txtCedula.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtCedula.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtCedula.ForeColor = System.Drawing.Color.Silver;
			this.txtCedula.Location = new System.Drawing.Point(443, 90);
			this.txtCedula.MaxLength = 9;
			this.txtCedula.Name = "txtCedula";
			this.txtCedula.Size = new System.Drawing.Size(293, 28);
			this.txtCedula.TabIndex = 2;
			this.txtCedula.Text = "Ej: 123456789";
			this.txtCedula.Enter += new System.EventHandler(this.txtCedula_Click);
			this.txtCedula.Leave += new System.EventHandler(this.txtCedula_Leave);
			// 
			// txtNombre
			// 
			this.txtNombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtNombre.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtNombre.ForeColor = System.Drawing.Color.Silver;
			this.txtNombre.Location = new System.Drawing.Point(443, 145);
			this.txtNombre.MaxLength = 100;
			this.txtNombre.Name = "txtNombre";
			this.txtNombre.Size = new System.Drawing.Size(293, 28);
			this.txtNombre.TabIndex = 3;
			this.txtNombre.Text = "Ej: Eyden Su Díaz";
			this.txtNombre.Enter += new System.EventHandler(this.txtNombre_Click);
			this.txtNombre.Leave += new System.EventHandler(this.txtNombre_Leave);
			// 
			// txtTelefono
			// 
			this.txtTelefono.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtTelefono.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtTelefono.ForeColor = System.Drawing.Color.Silver;
			this.txtTelefono.Location = new System.Drawing.Point(443, 372);
			this.txtTelefono.MaxLength = 20;
			this.txtTelefono.Name = "txtTelefono";
			this.txtTelefono.Size = new System.Drawing.Size(293, 28);
			this.txtTelefono.TabIndex = 5;
			this.txtTelefono.Text = "Ej: 88888888";
			this.txtTelefono.Enter += new System.EventHandler(this.txtTelefono_Click);
			this.txtTelefono.Leave += new System.EventHandler(this.txtTelefono_Leave);
			// 
			// txtEmail
			// 
			this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtEmail.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtEmail.ForeColor = System.Drawing.Color.Silver;
			this.txtEmail.Location = new System.Drawing.Point(443, 427);
			this.txtEmail.MaxLength = 200;
			this.txtEmail.Name = "txtEmail";
			this.txtEmail.Size = new System.Drawing.Size(293, 28);
			this.txtEmail.TabIndex = 6;
			this.txtEmail.Text = "Ej: ejemplo@gmail.com";
			this.txtEmail.Enter += new System.EventHandler(this.txtEmail_Click);
			this.txtEmail.Leave += new System.EventHandler(this.txtEmail_Leave);
			// 
			// btRegresar
			// 
			this.btRegresar.BackColor = System.Drawing.Color.Transparent;
			this.btRegresar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btRegresar.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btRegresar.ForeColor = System.Drawing.Color.LemonChiffon;
			this.btRegresar.Location = new System.Drawing.Point(13, 614);
			this.btRegresar.Margin = new System.Windows.Forms.Padding(4);
			this.btRegresar.Name = "btRegresar";
			this.btRegresar.Size = new System.Drawing.Size(101, 31);
			this.btRegresar.TabIndex = 12;
			this.btRegresar.Text = "Regresar";
			this.btRegresar.UseVisualStyleBackColor = false;
			this.btRegresar.Click += new System.EventHandler(this.btRegresar_Click);
			// 
			// lbCedula
			// 
			this.lbCedula.AutoSize = true;
			this.lbCedula.BackColor = System.Drawing.Color.Transparent;
			this.lbCedula.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbCedula.ForeColor = System.Drawing.Color.LemonChiffon;
			this.lbCedula.Location = new System.Drawing.Point(360, 93);
			this.lbCedula.Name = "lbCedula";
			this.lbCedula.Size = new System.Drawing.Size(67, 20);
			this.lbCedula.TabIndex = 16;
			this.lbCedula.Text = "Cédula:";
			this.lbCedula.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lbNombre
			// 
			this.lbNombre.AutoSize = true;
			this.lbNombre.BackColor = System.Drawing.Color.Transparent;
			this.lbNombre.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbNombre.ForeColor = System.Drawing.Color.LemonChiffon;
			this.lbNombre.Location = new System.Drawing.Point(355, 148);
			this.lbNombre.Name = "lbNombre";
			this.lbNombre.Size = new System.Drawing.Size(72, 20);
			this.lbNombre.TabIndex = 17;
			this.lbNombre.Text = "Nombre:";
			this.lbNombre.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lbBornDate
			// 
			this.lbBornDate.AutoSize = true;
			this.lbBornDate.BackColor = System.Drawing.Color.Transparent;
			this.lbBornDate.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbBornDate.ForeColor = System.Drawing.Color.LemonChiffon;
			this.lbBornDate.Location = new System.Drawing.Point(258, 203);
			this.lbBornDate.Name = "lbBornDate";
			this.lbBornDate.Size = new System.Drawing.Size(169, 20);
			this.lbBornDate.TabIndex = 18;
			this.lbBornDate.Text = "Fecha de nacimiento:";
			this.lbBornDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lbTelefono
			// 
			this.lbTelefono.AutoSize = true;
			this.lbTelefono.BackColor = System.Drawing.Color.Transparent;
			this.lbTelefono.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbTelefono.ForeColor = System.Drawing.Color.LemonChiffon;
			this.lbTelefono.Location = new System.Drawing.Point(352, 375);
			this.lbTelefono.Name = "lbTelefono";
			this.lbTelefono.Size = new System.Drawing.Size(75, 20);
			this.lbTelefono.TabIndex = 19;
			this.lbTelefono.Text = "Teléfono:";
			this.lbTelefono.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lbEmail
			// 
			this.lbEmail.AutoSize = true;
			this.lbEmail.BackColor = System.Drawing.Color.Transparent;
			this.lbEmail.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbEmail.ForeColor = System.Drawing.Color.LemonChiffon;
			this.lbEmail.Location = new System.Drawing.Point(377, 430);
			this.lbEmail.Name = "lbEmail";
			this.lbEmail.Size = new System.Drawing.Size(50, 20);
			this.lbEmail.TabIndex = 20;
			this.lbEmail.Text = "Email:";
			this.lbEmail.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// logoImg
			// 
			this.logoImg.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.logoImg.BackColor = System.Drawing.Color.Transparent;
			this.logoImg.BackgroundImage = global::PY1_BD.Properties.Resources.Color;
			this.logoImg.Image = global::PY1_BD.Properties.Resources.Logo;
			this.logoImg.Location = new System.Drawing.Point(0, 0);
			this.logoImg.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.logoImg.Name = "logoImg";
			this.logoImg.Size = new System.Drawing.Size(133, 118);
			this.logoImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.logoImg.TabIndex = 15;
			this.logoImg.TabStop = false;
			// 
			// btAgregar
			// 
			this.btAgregar.BackColor = System.Drawing.Color.Transparent;
			this.btAgregar.BackgroundImage = global::PY1_BD.Properties.Resources.Color;
			this.btAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btAgregar.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btAgregar.ForeColor = System.Drawing.Color.LemonChiffon;
			this.btAgregar.Location = new System.Drawing.Point(460, 605);
			this.btAgregar.Margin = new System.Windows.Forms.Padding(4);
			this.btAgregar.Name = "btAgregar";
			this.btAgregar.Size = new System.Drawing.Size(185, 46);
			this.btAgregar.TabIndex = 9;
			this.btAgregar.Text = "Agregar";
			this.btAgregar.UseVisualStyleBackColor = false;
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackgroundImage = global::PY1_BD.Properties.Resources.Color;
			this.pictureBox1.Location = new System.Drawing.Point(0, -5);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(255, 671);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// lbAddress
			// 
			this.lbAddress.AutoSize = true;
			this.lbAddress.BackColor = System.Drawing.Color.Transparent;
			this.lbAddress.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbAddress.ForeColor = System.Drawing.Color.LemonChiffon;
			this.lbAddress.Location = new System.Drawing.Point(343, 255);
			this.lbAddress.Name = "lbAddress";
			this.lbAddress.Size = new System.Drawing.Size(84, 20);
			this.lbAddress.TabIndex = 21;
			this.lbAddress.Text = "Dirección:";
			this.lbAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lbGenero
			// 
			this.lbGenero.AutoSize = true;
			this.lbGenero.BackColor = System.Drawing.Color.Transparent;
			this.lbGenero.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbGenero.ForeColor = System.Drawing.Color.LemonChiffon;
			this.lbGenero.Location = new System.Drawing.Point(357, 329);
			this.lbGenero.Name = "lbGenero";
			this.lbGenero.Size = new System.Drawing.Size(70, 20);
			this.lbGenero.TabIndex = 22;
			this.lbGenero.Text = "Género:";
			this.lbGenero.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lbRol
			// 
			this.lbRol.AutoSize = true;
			this.lbRol.BackColor = System.Drawing.Color.Transparent;
			this.lbRol.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbRol.ForeColor = System.Drawing.Color.LemonChiffon;
			this.lbRol.Location = new System.Drawing.Point(392, 485);
			this.lbRol.Name = "lbRol";
			this.lbRol.Size = new System.Drawing.Size(35, 20);
			this.lbRol.TabIndex = 23;
			this.lbRol.Text = "Rol:";
			this.lbRol.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lbPassword
			// 
			this.lbPassword.AutoSize = true;
			this.lbPassword.BackColor = System.Drawing.Color.Transparent;
			this.lbPassword.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbPassword.ForeColor = System.Drawing.Color.LemonChiffon;
			this.lbPassword.Location = new System.Drawing.Point(328, 540);
			this.lbPassword.Name = "lbPassword";
			this.lbPassword.Size = new System.Drawing.Size(99, 20);
			this.lbPassword.TabIndex = 24;
			this.lbPassword.Text = "Contraseña:";
			this.lbPassword.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txtAddress
			// 
			this.txtAddress.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtAddress.ForeColor = System.Drawing.Color.Silver;
			this.txtAddress.Location = new System.Drawing.Point(443, 255);
			this.txtAddress.Multiline = true;
			this.txtAddress.Name = "txtAddress";
			this.txtAddress.Size = new System.Drawing.Size(293, 56);
			this.txtAddress.TabIndex = 25;
			this.txtAddress.Text = "Ej: Colina";
			// 
			// txtPassword
			// 
			this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtPassword.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtPassword.ForeColor = System.Drawing.Color.Silver;
			this.txtPassword.Location = new System.Drawing.Point(443, 537);
			this.txtPassword.MaxLength = 200;
			this.txtPassword.Name = "txtPassword";
			this.txtPassword.Size = new System.Drawing.Size(293, 28);
			this.txtPassword.TabIndex = 29;
			this.txtPassword.Text = "Ingrese una contraseña";
			// 
			// comboBox1
			// 
			this.comboBox1.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Location = new System.Drawing.Point(443, 481);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(293, 29);
			this.comboBox1.TabIndex = 30;
			// 
			// rbMas
			// 
			this.rbMas.AutoSize = true;
			this.rbMas.ForeColor = System.Drawing.Color.LemonChiffon;
			this.rbMas.Location = new System.Drawing.Point(443, 330);
			this.rbMas.Name = "rbMas";
			this.rbMas.Size = new System.Drawing.Size(89, 20);
			this.rbMas.TabIndex = 26;
			this.rbMas.TabStop = true;
			this.rbMas.Text = "Masculino";
			this.rbMas.UseVisualStyleBackColor = true;
			// 
			// rbFem
			// 
			this.rbFem.AutoSize = true;
			this.rbFem.ForeColor = System.Drawing.Color.LemonChiffon;
			this.rbFem.Location = new System.Drawing.Point(555, 330);
			this.rbFem.Name = "rbFem";
			this.rbFem.Size = new System.Drawing.Size(88, 20);
			this.rbFem.TabIndex = 27;
			this.rbFem.TabStop = true;
			this.rbFem.Text = "Femenino";
			this.rbFem.UseVisualStyleBackColor = true;
			// 
			// dtpBornDate
			// 
			this.dtpBornDate.CalendarFont = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.dtpBornDate.CustomFormat = "yyyy-MM-dd";
			this.dtpBornDate.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.dtpBornDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtpBornDate.Location = new System.Drawing.Point(443, 200);
			this.dtpBornDate.Name = "dtpBornDate";
			this.dtpBornDate.Size = new System.Drawing.Size(138, 28);
			this.dtpBornDate.TabIndex = 31;
			// 
			// VistaAgregarPersonal
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.ClientSize = new System.Drawing.Size(832, 664);
			this.Controls.Add(this.dtpBornDate);
			this.Controls.Add(this.comboBox1);
			this.Controls.Add(this.txtPassword);
			this.Controls.Add(this.rbFem);
			this.Controls.Add(this.rbMas);
			this.Controls.Add(this.txtAddress);
			this.Controls.Add(this.lbPassword);
			this.Controls.Add(this.lbRol);
			this.Controls.Add(this.lbGenero);
			this.Controls.Add(this.lbAddress);
			this.Controls.Add(this.lbEmail);
			this.Controls.Add(this.lbTelefono);
			this.Controls.Add(this.lbBornDate);
			this.Controls.Add(this.lbNombre);
			this.Controls.Add(this.lbCedula);
			this.Controls.Add(this.logoImg);
			this.Controls.Add(this.btRegresar);
			this.Controls.Add(this.btAgregar);
			this.Controls.Add(this.txtEmail);
			this.Controls.Add(this.txtTelefono);
			this.Controls.Add(this.txtNombre);
			this.Controls.Add(this.txtCedula);
			this.Controls.Add(this.lbTitle);
			this.Controls.Add(this.pictureBox1);
			this.Name = "VistaAgregarPersonal";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Agregar Clientes";
			((System.ComponentModel.ISupportInitialize)(this.logoImg)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label lbTitle;
		public System.Windows.Forms.Button btAgregar;
		public System.Windows.Forms.Button btRegresar;
		private System.Windows.Forms.PictureBox logoImg;
		private System.Windows.Forms.Label lbCedula;
		private System.Windows.Forms.Label lbNombre;
		private System.Windows.Forms.Label lbBornDate;
		private System.Windows.Forms.Label lbTelefono;
		private System.Windows.Forms.Label lbEmail;
		public System.Windows.Forms.TextBox txtCedula;
		public System.Windows.Forms.TextBox txtNombre;
		public System.Windows.Forms.TextBox txtTelefono;
		public System.Windows.Forms.TextBox txtEmail;
		private System.Windows.Forms.Label lbAddress;
		private System.Windows.Forms.Label lbGenero;
		private System.Windows.Forms.Label lbRol;
		private System.Windows.Forms.Label lbPassword;
		private System.Windows.Forms.TextBox txtAddress;
		public System.Windows.Forms.TextBox txtPassword;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.RadioButton rbMas;
		private System.Windows.Forms.RadioButton rbFem;
		public System.Windows.Forms.DateTimePicker dtpBornDate;
	}
}