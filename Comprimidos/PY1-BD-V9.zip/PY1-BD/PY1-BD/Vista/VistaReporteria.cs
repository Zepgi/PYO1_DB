﻿using PY1_BD.Modelo;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PY1_BD.Vista {

    public partial class VistaReporteria : Form {

        public SqlConnection bdHotel;
        public VistaReporteria(SqlConnection pbdHotel) {
            this.bdHotel = pbdHotel;
            InitializeComponent();
        }

        private void VistaReporteria_Load(object sender, EventArgs e)
        {

        }
    }

      
    
}
